"""
GearHeadSpecs — application server.

Pure Python standard library. Run with:  py app.py
Serves the REST API on /api/* and the pages in static/ on /.

Auth is a session cookie backed by the sessions table. Role gates live in the
route table itself (the `role` column), so the gate sits next to the route
rather than somewhere a reader has to go looking for.

Roles, least to most: user, manager, admin. There is no stored role for a
visitor who is not signed in — that is 'anon' on a route, and it means the
route is deliberately open. Note the default is 'anon', so a route that omits
the role is PUBLICLY READABLE; anything that writes, or reads somebody's
private data, has to name its role explicitly.
"""
import json
import os
import re
import sqlite3
import hashlib
import hmac
import secrets
import mimetypes
from datetime import datetime, timedelta, timezone
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote, quote

import questionnaire
import wire_colors
import fuel_octane

ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(ROOT, "data.db")
STATIC_DIR = os.path.join(ROOT, "static")

PORT = int(os.environ.get("PORT", "8420"))
SESSION_DAYS = 14
PBKDF2_ROUNDS = 200_000
COOKIE_NAME = "ghs_session"


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def rows(cur):
    return [dict(r) for r in cur.fetchall()]


def one(cur):
    r = cur.fetchone()
    return dict(r) if r else None


class HttpError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


# ---------------------------------------------------------------------------
# Passwords and sessions
# ---------------------------------------------------------------------------
def hash_password(password, salt):
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt.encode("utf-8"), PBKDF2_ROUNDS
    ).hex()


def verify_password(password, stored_hash, salt):
    # compare_digest, not ==, so a wrong password cannot be narrowed down by
    # timing how long the comparison took.
    return hmac.compare_digest(hash_password(password, salt), stored_hash)


def create_session(conn, user_id):
    token = secrets.token_urlsafe(32)
    expires = datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)
    conn.execute(
        "INSERT INTO sessions (token, user_id, expires_at) VALUES (?,?,?)",
        (token, user_id, expires.strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()
    return token


def user_for_token(conn, token):
    if not token:
        return None
    return one(conn.execute(
        "SELECT u.id, u.username, u.display_name, u.role, u.suspended"
        " FROM sessions s JOIN users u ON u.id = s.user_id"
        " WHERE s.token = ? AND s.expires_at > datetime('now')", (token,)))


ROLE_RANK = {"user": 0, "manager": 1, "admin": 2}


def manages_bike(conn, user, bike_id):
    """Admins can act on any bike; a manager only on bikes assigned to them.

    This is the rule that makes the flag queue meaningful — 'the person closest
    to the bike' has to actually be enforced, not just displayed.
    """
    if user["role"] == "admin":
        return True
    return conn.execute(
        "SELECT 1 FROM bike_managers WHERE user_id=? AND bike_id=?",
        (user["id"], bike_id)).fetchone() is not None


def require_manages(conn, user, bike_id):
    if not manages_bike(conn, user, bike_id):
        raise HttpError(403, "you do not manage this bike")


def check_value(conn, spec_id, value):
    """Normalise a value against its field's type, or refuse it.

    Every path that writes a value goes through here — the manager's edit, a
    rider's submission, an alternate — so a wire colour cannot arrive as free
    text through whichever door happens to be unguarded.
    """
    row = conn.execute(
        "SELECT f.value_type, f.label FROM specs s"
        " JOIN spec_fields f ON f.field_key = s.field_key WHERE s.id=?",
        (spec_id,)).fetchone()
    if not row or row["value_type"] == "text":
        return value
    if value is None or not str(value).strip():
        return value
    try:
        if row["value_type"] == "wire_color":
            # normalise_set, not normalise: a spec can be several wires — a
            # kickstand switch has two — and one wire is simply a list of one.
            return wire_colors.normalise_set(value)
        if row["value_type"] == "fuel_octane":
            return fuel_octane.normalise_octane(value)
        if row["value_type"] == "ethanol":
            return fuel_octane.normalise_ethanol(value)
    except (wire_colors.WireColorError, fuel_octane.FuelValueError) as e:
        raise HttpError(400, f"{row['label']}: {e}")
    return value


def refuse_if_paused(conn, user, spec_id):
    """Offline means offline: no votes, flags or submissions while it is down.

    Hiding the value without closing these would leave riders voting on a
    number they cannot see. The bike's manager is exempt — they took it offline
    to work on it, and the fix is a write.
    """
    row = conn.execute(
        "SELECT s.paused, s.bike_id, f.label FROM specs s"
        " JOIN spec_fields f ON f.field_key = s.field_key WHERE s.id=?",
        (spec_id,)).fetchone()
    if not row or not row["paused"]:
        return
    if user and manages_bike(conn, user, row["bike_id"]):
        return
    raise HttpError(409, f"\"{row['label']}\" is offline while its manager "
                         f"reviews it — it will be back shortly")


# ---------------------------------------------------------------------------
# Routing
# ---------------------------------------------------------------------------
ROUTES = []


def route(method, pattern, role="anon"):
    """role: anon | user | manager | admin

    anon   — no session needed, including visitors who are not signed in
    user   — any signed-in account
    manager/admin — minimum role rank
    """
    compiled = re.compile("^" + pattern + "$")

    def wrap(fn):
        ROUTES.append((method, compiled, fn, role))
        return fn
    return wrap


class Ctx:
    def __init__(self, conn, user, params, query, body):
        self.conn = conn
        self.user = user
        self.params = params
        self.query = query
        self.body = body

    def arg(self, name, default=None):
        v = self.query.get(name)
        return v[0] if v else default

    def field(self, name, required=True, default=None):
        v = self.body.get(name, default)
        if required and (v is None or (isinstance(v, str) and not v.strip())):
            raise HttpError(400, f"missing field: {name}")
        return v.strip() if isinstance(v, str) else v


# ===========================================================================
# AUTH
# ===========================================================================
@route("POST", r"/api/auth/login")
def login(ctx):
    username = ctx.field("username")
    password = ctx.field("password")
    u = one(ctx.conn.execute(
        "SELECT * FROM users WHERE username = ?", (username,)))
    # Same error for unknown user and wrong password: telling them apart is a
    # free list of valid usernames.
    if not u or not verify_password(password, u["password_hash"], u["password_salt"]):
        raise HttpError(401, "invalid username or password")
    if u["suspended"]:
        raise HttpError(403, "this account is suspended")
    token = create_session(ctx.conn, u["id"])
    return {"user": {"id": u["id"], "username": u["username"],
                     "display_name": u["display_name"], "role": u["role"]},
            "_set_cookie": token}


# Rules kept next to the route that enforces them, and quoted verbatim by the
# register page so the two can never tell the reader different things.
USERNAME_MIN, USERNAME_MAX = 3, 32
PASSWORD_MIN = 10
USERNAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]*$")
# Loose on purpose: one @, something either side, a dot in the domain. The
# only way to really validate an address is to send to it, and this does not.
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
EMAIL_MAX = 254


@route("POST", r"/api/auth/register")
def register(ctx):
    """Open registration. The account always comes out as a plain reader.

    `role` is never read from the body. A new account is 'user' and nothing
    else: manager is something an admin grants by assigning a bike, and admin
    is not grantable through the API at all. Accepting a role here would let
    anyone who can reach the endpoint hand themselves the platform.

    A taken username has to be reported as taken -- the person needs to pick
    another one -- so this endpoint can confirm whether a name exists, unlike
    login, which deliberately cannot. That is inherent to registration rather
    than an oversight.
    """
    username = ctx.field("username")
    password = ctx.field("password")
    email = ctx.field("email").lower()
    display = (ctx.body.get("display_name") or "").strip() or None

    if len(email) > EMAIL_MAX or not EMAIL_RE.match(email):
        raise HttpError(400, "that does not look like an email address")

    if not USERNAME_MIN <= len(username) <= USERNAME_MAX:
        raise HttpError(400, f"username must be {USERNAME_MIN}-{USERNAME_MAX}"
                             f" characters")
    if not USERNAME_RE.match(username):
        raise HttpError(400, "username can use letters, numbers, dot, dash and"
                             " underscore, and must start with a letter or number")
    if len(password) < PASSWORD_MIN:
        raise HttpError(400, f"password must be at least {PASSWORD_MIN} characters")
    # The two most common passwords on any site are the site's own name and the
    # username. Refusing them costs nothing and removes the easiest guesses.
    if password.lower() in (username.lower(), "gearheadspecs", "gearhead"):
        raise HttpError(400, "pick a password that is not your username or the"
                             " site's name")
    if display and len(display) > 60:
        raise HttpError(400, "display name must be 60 characters or fewer")

    if ctx.conn.execute("SELECT 1 FROM users WHERE username = ?",
                        (username,)).fetchone():
        raise HttpError(409, f"the username {username!r} is taken")
    # Same reasoning as the username: the person has to be told, so they can
    # sign in to the account they already have instead of making a second one.
    if ctx.conn.execute("SELECT 1 FROM users WHERE email = ? COLLATE NOCASE",
                        (email,)).fetchone():
        raise HttpError(409, "an account with that email already exists — sign in instead")

    salt = secrets.token_hex(16)
    cur = ctx.conn.execute(
        "INSERT INTO users (username, display_name, role, password_hash,"
        " password_salt, email) VALUES (?,?,'user',?,?,?)",
        (username, display, hash_password(password, salt), salt, email))
    uid = cur.lastrowid
    ctx.conn.commit()

    # Signed in on the way out: making somebody type the same credentials again
    # immediately after choosing them is friction with nothing behind it.
    token = create_session(ctx.conn, uid)
    return {"user": {"id": uid, "username": username,
                     "display_name": display, "role": "user"},
            "_set_cookie": token}


@route("POST", r"/api/auth/logout", role="user")
def logout(ctx):
    ctx.conn.execute("DELETE FROM sessions WHERE user_id = ?", (ctx.user["id"],))
    ctx.conn.commit()
    return {"ok": True, "_clear_cookie": True}


@route("GET", r"/api/auth/me")
def me(ctx):
    if not ctx.user:
        return {"user": None}
    managed = rows(ctx.conn.execute(
        "SELECT bike_id FROM bike_managers WHERE user_id=?", (ctx.user["id"],)))
    return {"user": ctx.user, "manages": [m["bike_id"] for m in managed]}


# ===========================================================================
# CATALOG / BROWSE
# ===========================================================================
@route("GET", r"/api/catalog/filters")
def catalog_filters(ctx):
    """Options for the make / year / model selects, narrowed by whatever is
    already chosen so the dropdowns cannot offer a combination with no rows."""
    make = ctx.arg("make")
    year = ctx.arg("year")
    model = ctx.arg("model")

    where, args = [], []
    if make:
        where.append("b.make = ?"); args.append(make)
    if year:
        where.append("y.year = ?"); args.append(year)
    if model:
        where.append("b.model_code = ?"); args.append(model)
    clause = (" WHERE " + " AND ".join(where)) if where else ""

    def distinct(col, extra_where=None):
        w, a = list(where), list(args)
        if extra_where:
            # Drop the constraint on the column being listed, so choosing a
            # model does not reduce the model list to just that model.
            w = [x for x in w if not x.startswith(extra_where)]
            a = [args[i] for i, x in enumerate(where) if not x.startswith(extra_where)]
        c = (" WHERE " + " AND ".join(w)) if w else ""
        return [r[0] for r in ctx.conn.execute(
            f"SELECT DISTINCT {col} FROM bike_years y"
            f" JOIN bikes b ON b.id = y.bike_id{c}"
            f" ORDER BY {col}", a)]

    # Models are ordered by engine size, not alphabetically — a rider scanning
    # for "something around 600cc" gets a useful ordering, where an alphabetical
    # list interleaves a 50cc scooter with a litre bike.
    #
    # The cc is parsed out of the Engine Displacement spec ("919cc" -> 919)
    # rather than stored separately, so it cannot fall out of step with the
    # value shown on the page. Models with no displacement recorded sort last
    # instead of pretending to be 0cc.
    mw, ma = list(where), list(args)
    mw = [x for x in mw if not x.startswith("b.model_code")]
    ma = [args[i] for i, x in enumerate(where) if not x.startswith("b.model_code")]
    mc = (" WHERE " + " AND ".join(mw)) if mw else ""
    models = rows(ctx.conn.execute(
        f"SELECT b.model_code,"
        f"       MAX(CAST(NULLIF(REPLACE(IFNULL(s.value,''),'cc',''),'') AS INTEGER)) AS cc"
        f" FROM bike_years y"
        f" JOIN bikes b ON b.id = y.bike_id"
        f" LEFT JOIN specs s ON s.bike_id = b.id AND s.field_key = 'engine_displacement'"
        f"{mc}"
        f" GROUP BY b.model_code"
        f" ORDER BY (cc IS NULL), cc, b.model_code", ma))

    return {
        "makes":  distinct("b.make", "b.make"),
        "years":  distinct("y.year", "y.year"),
        "models": models,
    }


@route("GET", r"/api/bikes")
def list_bikes(ctx):
    """Search hits bike_names, so 'Hornet 900' and 'CB919' find the same
    machine — the whole point of names being data rather than identity."""
    make, year, model = ctx.arg("make"), ctx.arg("year"), ctx.arg("model")
    q = ctx.arg("q")
    limit = min(int(ctx.arg("limit", "200")), 1000)

    where, args = [], []
    if make:
        where.append("d.make = ?"); args.append(make)
    if model:
        where.append("d.model_code = ?"); args.append(model)
    if year:
        where.append("EXISTS (SELECT 1 FROM bike_years y WHERE y.bike_id=d.bike_id AND y.year=?)")
        args.append(year)
    if q:
        where.append(
            "(EXISTS (SELECT 1 FROM bike_names n WHERE n.bike_id=d.bike_id"
            "         AND n.name LIKE ?) OR d.model_code LIKE ?)")
        args += [f"%{q}%", f"%{q}%"]
    clause = (" WHERE " + " AND ".join(where)) if where else ""

    # The catalog listing is the public view of every bike, so it reports the
    # public numbers even to a manager: this is the browse page, not their
    # dashboard, and the counts should match what the spec sheet will show.
    result = rows(ctx.conn.execute(
        "SELECT d.*, p.fields_triggered_public AS fields_triggered,"
        "       p.specs_filled_public AS specs_filled,"
        "       p.specs_needed_public AS specs_needed"
        " FROM bike_display d"
        " JOIN bike_spec_progress p ON p.bike_id = d.bike_id"
        f"{clause} ORDER BY d.model_code, d.year_start LIMIT ?", args + [limit]))
    total = ctx.conn.execute(
        f"SELECT COUNT(*) FROM bike_display d{clause}", args).fetchone()[0]
    return {"bikes": result, "total": total}


@route("GET", r"/api/bikes/(\d+)")
def get_bike(ctx):
    bike_id = int(ctx.params[0])
    # The header counts have to agree with the rows underneath them. Whoever
    # looks after the bike sees its offline specs, so they are counted for them
    # and not for anybody else.
    mine = bool(ctx.user) and manages_bike(ctx.conn, ctx.user, bike_id)
    cols = ("p.fields_triggered, p.specs_filled, p.specs_needed" if mine else
            "p.fields_triggered_public AS fields_triggered,"
            " p.specs_filled_public AS specs_filled,"
            " p.specs_needed_public AS specs_needed")
    bike = one(ctx.conn.execute(
        f"SELECT d.*, {cols}, p.specs_offline, b.split_from_bike_id, b.split_at_year"
        " FROM bike_display d JOIN bike_spec_progress p ON p.bike_id=d.bike_id"
        " JOIN bikes b ON b.id=d.bike_id"
        " WHERE d.bike_id = ?", (bike_id,)))
    if not bike:
        raise HttpError(404, "bike not found")
    if not mine:
        bike["specs_offline"] = 0
    bike["names"] = rows(ctx.conn.execute(
        "SELECT name, market, is_primary FROM bike_names WHERE bike_id=?"
        " ORDER BY is_primary DESC, name", (bike_id,)))
    bike["photo"] = photo_of(ctx.conn, bike_id)
    bike["years"] = rows(ctx.conn.execute(
        "SELECT id AS bike_year_id, year, in_v2 FROM bike_years"
        " WHERE bike_id=? ORDER BY year", (bike_id,)))
    bike["managers"] = rows(ctx.conn.execute(
        "SELECT u.id, u.username, u.display_name, m.specialty"
        " FROM bike_managers m JOIN users u ON u.id = m.user_id"
        " WHERE m.bike_id=?", (bike_id,)))
    return bike


@route("GET", r"/api/fuel-octane")
def fuel_octane_vocabulary(ctx):
    """Pump grades, their cross-region equivalents with provenance, and the
    ethanol ceilings. The equivalents are looked up, never computed: AKI cannot
    be derived from RON without MON, which no manual publishes."""
    return fuel_octane.vocabulary()


@route("GET", r"/api/wire-colors")
def wire_color_vocabulary(ctx):
    """The colour list, and the abbreviations for one make.

    ?make= because the same stored colour is written differently depending on
    whose diagram the rider is holding: Honda prints Bu for blue, Kawasaki BL,
    Harley BE. The value never changes; only the label does.
    """
    return wire_colors.vocabulary(ctx.arg("make", "") or None)


@route("GET", r"/api/bikes/(\d+)/specs")
def get_bike_specs(ctx):
    bike_id = int(ctx.params[0])
    uid = ctx.user["id"] if ctx.user else -1
    spec_rows = rows(ctx.conn.execute(
        # open_flags counts only flags against the STOCK value: a flag carrying
        # an alternate_id belongs to that alternate's line, not to the spec.
        "SELECT s.id, s.field_key, s.value, s.confidence, s.tools,"
        "       f.label, f.category, f.sort_order,"
        # Effective type: a manager's per-bike override wins over the
        # platform default, so one bike can call a field Fixed without
        # changing that field for the other 259.
        "       COALESCE(s.spec_type, f.spec_type) AS spec_type,"
        "       (s.spec_type IS NOT NULL) AS type_overridden,"
        "       f.spec_type AS field_spec_type,"
        "       u.username AS entered_by_username, s.entered_by,"
        "       vc.votes, rc.requests,"
        "       EXISTS(SELECT 1 FROM spec_votes v"
        "              WHERE v.spec_id=s.id AND v.user_id=?) AS my_vote,"
        "       EXISTS(SELECT 1 FROM spec_requests r"
        "              WHERE r.spec_id=s.id AND r.user_id=?) AS my_request,"
        # Whether YOU have an open flag on the stock value — the alternates
        # carry the same field, and without it the page cannot show a flag you
        # already raised as raised.
        "       EXISTS(SELECT 1 FROM value_flags vf"
        "              WHERE vf.spec_id=s.id AND vf.alternate_id IS NULL"
        "                AND vf.flagged_by=? AND vf.status='open') AS my_flag,"
        "       (SELECT COUNT(*) FROM value_flags vf"
        "         WHERE vf.spec_id = s.id AND vf.alternate_id IS NULL"
        "           AND vf.status='open') AS open_flags,"
        # Lifted into this bike's hero by its manager. General is in the
        # hero on every bike regardless; this is the per-bike addition.
        # in_header means "pinned": a non-General field lifted into the hero.
        # header_hidden means a General field this bike's manager took OUT.
        "       EXISTS(SELECT 1 FROM bike_header_specs h"
        "              WHERE h.bike_id = s.bike_id"
        "                AND h.field_key = s.field_key"
        "                AND h.hidden = 0) AS in_header,"
        "       EXISTS(SELECT 1 FROM bike_header_specs h"
        "              WHERE h.bike_id = s.bike_id"
        "                AND h.field_key = s.field_key"
        "                AND h.hidden = 1) AS header_hidden,"
        "       COALESCE((SELECT h.hide_below FROM bike_header_specs h"
        "                  WHERE h.bike_id = s.bike_id"
        "                    AND h.field_key = s.field_key), 0) AS header_only,"
        "       s.paused, s.paused_at, pu.username AS paused_by_username,"
        "       f.value_type, s.year_from, s.year_to,"
        # The other headings this bike's manager put the field under, and
        # whether they took it out of its home heading on this bike.
        "       (SELECT GROUP_CONCAT(c.category, '|') FROM bike_spec_categories c"
        "         WHERE c.bike_id = s.bike_id AND c.field_key = s.field_key"
        "           AND c.shown = 1) AS also_in,"
        "       EXISTS(SELECT 1 FROM bike_spec_categories c"
        "         WHERE c.bike_id = s.bike_id AND c.field_key = s.field_key"
        "           AND c.shown = 0) AS home_hidden_bike,"
        # ...and the same, set by admin for every bike.
        "       (SELECT GROUP_CONCAT(g.category, '|') FROM spec_field_categories g"
        "         WHERE g.field_key = s.field_key AND g.shown = 1) AS also_in_site,"
        "       EXISTS(SELECT 1 FROM spec_field_categories g"
        "         WHERE g.field_key = s.field_key AND g.shown = 0) AS home_hidden_site,"
        # How many rows this field has on this bike. One is the ordinary case;
        # more means the value changed partway through the bike's life and the
        # page has to say so rather than pick one.
        "       (SELECT COUNT(*) FROM specs v WHERE v.bike_id = s.bike_id"
        "          AND v.field_key = s.field_key) AS variant_count"
        " FROM specs s"
        " JOIN spec_fields f ON f.field_key = s.field_key"
        " JOIN spec_vote_counts vc ON vc.spec_id = s.id"
        " JOIN spec_request_counts rc ON rc.spec_id = s.id"
        " LEFT JOIN users u ON u.id = s.entered_by"
        " LEFT JOIN users pu ON pu.id = s.paused_by"
        " WHERE s.bike_id = ?"
        # Variants of one field sit together, earliest year first, so the page
        # can group consecutive rows without a second pass.
        " ORDER BY f.sort_order, f.label, s.year_from", (uid, uid, uid, bike_id)))

    alts = rows(ctx.conn.execute(
        "SELECT a.id, a.spec_id, a.text, a.confirmed_fit, a.paused,"
        "       c.votes, u.username AS submitted_by_username,"
        "       EXISTS(SELECT 1 FROM alternate_votes v"
        "              WHERE v.alternate_id=a.id AND v.user_id=?) AS my_vote,"
        "       EXISTS(SELECT 1 FROM value_flags vf"
        "              WHERE vf.alternate_id=a.id AND vf.flagged_by=?"
        "                AND vf.status='open') AS my_flag,"
        "       (SELECT COUNT(*) FROM value_flags vf"
        "         WHERE vf.alternate_id=a.id AND vf.status='open') AS flags"
        " FROM spec_alternates a"
        " JOIN alternate_vote_counts c ON c.alternate_id = a.id"
        " LEFT JOIN users u ON u.id = a.submitted_by"
        " JOIN specs s ON s.id = a.spec_id"
        " WHERE s.bike_id = ? ORDER BY c.votes DESC, a.id", (uid, uid, bike_id)))

    by_spec = {}
    for a in alts:
        by_spec.setdefault(a["spec_id"], []).append(a)

    # Whoever looks after this bike keeps seeing everything — they cannot judge
    # a value they have taken offline if the page hides it from them too.
    manages = bool(ctx.user) and manages_bike(ctx.conn, ctx.user, bike_id)

    categories, unplaced = [], []
    for s in spec_rows:
        # Offline means gone from the sheet, not greyed out on it. A row that
        # announces a field while withholding its value still tells a rider the
        # bike has that spec, and the whole point of taking one offline is that
        # it should not be read at all until it has been checked.
        if s["paused"] and not manages:
            continue
        s["alternates"] = by_spec.get(s["id"], [])
        # Where this spec shows on this bike. Its home heading, unless taken
        # out of it (on this bike, or site-wide), plus every extra heading.
        # `lead` is the heading that carries the row; the rest mirror it.
        # also_in_site and home_locked are the part a bike's manager cannot
        # change: admin decided those for every bike.
        order = lambda c: CATEGORY_ORDER.index(c) if c in CATEGORY_ORDER else 99
        s["also_in_site"] = sorted((c for c in (s["also_in_site"] or "").split("|") if c), key=order)
        mine = [c for c in (s["also_in"] or "").split("|") if c]
        extras = sorted((set(mine) | set(s["also_in_site"])) - {s["category"]}, key=order)
        s["home_shown"] = not (s["home_hidden_bike"] or s["home_hidden_site"])
        s["home_locked"] = bool(s["home_hidden_site"])
        shown = ([s["category"]] if s["home_shown"] else []) + extras
        s["lead"] = shown[0] if shown else None
        s["also_in"] = shown[1:]
        # No heading at all: the spec is in the header (if pinned there, or
        # General) and nowhere else. Its manager still gets it, in a section of
        # its own at the end, because a spec nobody can reach cannot be fixed.
        if not shown:
            unplaced.append(s)
            continue
        if not categories or categories[-1]["name"] != s["lead"]:
            categories.append({"name": s["lead"], "specs": [], "echoes": []})
        categories[-1]["specs"].append(s)
    # Skipping rows can empty a category. An empty heading on the page, and an
    # entry in the jump-to sidebar that scrolls to nothing, would both be
    # artefacts of hiding rather than anything about the bike.
    # Rows arrive in home order, but a spec taken out of its home leads
    # under another heading, so the same heading can open twice; fold them.
    merged = {}
    for c in categories:
        if c["name"] in merged:
            merged[c["name"]]["specs"].extend(c["specs"])
        else:
            merged[c["name"]] = c
    categories = [c for c in merged.values() if c["specs"]]

    # A spec shown under more than one heading mirrors under the others,
    # after that heading's own specs. A heading with nothing of its own but
    # a mirror still gets printed.
    echoed = [s for c in categories for s in c["specs"] if s["also_in"]]
    by_name = {c["name"]: c for c in categories}
    for s in echoed:
        for name in s["also_in"]:
            if name not in by_name:
                by_name[name] = {"name": name, "specs": [], "echoes": []}
                categories.append(by_name[name])
            by_name[name]["echoes"].append(s)
    order = {n: i for i, n in enumerate(CATEGORY_ORDER)}
    categories.sort(key=lambda c: order.get(c["name"], 99))
    return {"categories": categories, "unplaced": unplaced}


# ===========================================================================
# COMMUNITY: alternates, votes, flags
# ===========================================================================
@route("POST", r"/api/specs/(\d+)/alternates", role="user")
def add_alternate(ctx):
    spec_id = int(ctx.params[0])
    refuse_if_paused(ctx.conn, ctx.user, spec_id)
    spec = one(ctx.conn.execute(
        "SELECT s.id, s.bike_id, COALESCE(s.spec_type, f.spec_type) AS spec_type"
        " FROM specs s"
        " JOIN spec_fields f ON f.field_key=s.field_key WHERE s.id=?", (spec_id,)))
    if not spec:
        raise HttpError(404, "spec not found")
    # A 'fixed' field has one correct answer. Accepting alternates there would
    # invite a vote on a fact.
    if spec["spec_type"] == "fixed":
        raise HttpError(400, "this field has a single correct value — "
                             "flag it as incorrect instead of proposing an alternate")
    cur = ctx.conn.execute(
        "INSERT INTO spec_alternates (spec_id, text, submitted_by) VALUES (?,?,?)",
        (spec_id, check_value(ctx.conn, spec_id, ctx.field("text")),
         ctx.user["id"]))
    ctx.conn.commit()
    return {"id": cur.lastrowid}


@route("POST", r"/api/specs/(\d+)/value", role="user")
def submit_spec_value(ctx):
    """Anyone signed in can fill an EMPTY spec.

    This is the point of a community database: a rider who knows the battery
    their bike takes should be able to say so, without waiting for the assigned
    manager to get to it.

    Only a gap, though. Filling a blank is additive — nothing is lost if it
    turns out wrong, and the manager sees it for review. Overwriting a value
    somebody already sourced is destructive and stays a flag, so that the
    existing value survives until a human decides.

    The value lands as 'pending': sourced by a person, not yet confirmed. It
    shows on the page as Unsourced, which is honest, and it sits in the
    manager's review queue until they confirm or correct it.
    """
    spec_id = int(ctx.params[0])
    refuse_if_paused(ctx.conn, ctx.user, spec_id)
    spec = one(ctx.conn.execute(
        "SELECT s.*, f.label, COALESCE(s.spec_type, f.spec_type) AS effective_type"
        " FROM specs s"
        " JOIN spec_fields f ON f.field_key = s.field_key WHERE s.id = ?", (spec_id,)))
    if not spec:
        raise HttpError(404, "spec not found")
    if spec["value"] not in (None, ""):
        raise HttpError(409, "this spec already has a value — flag it as "
                             "incorrect, or suggest an alternate, instead of "
                             "overwriting it")
    # A spec the manager has explicitly tagged Fixed is closed to
    # contributions: one correct value, set by the rider who maintains the bike.
    #
    # Note this tests s.spec_type — the manager's per-bike tag — NOT the
    # effective type. Almost every field in the tree defaults to 'fixed'
    # (2,927 of 2,932 rows), so honouring the inherited default here would shut
    # the community out of ~1,950 empty specs and cancel the "anyone can fill a
    # gap" behaviour entirely. The inherited default already does its job by
    # refusing alternates; closing a spec to values is a deliberate act by the
    # person who maintains that particular bike.
    #
    # The manager is not blocked by their own tag — it is how they claim a
    # spec, not how they lock themselves out of it.
    if (spec["spec_type"] == "fixed"
            and not manages_bike(ctx.conn, ctx.user, spec["bike_id"])):
        raise HttpError(403, "this spec is marked Fixed — only the rider who "
                             "maintains this bike sets its value. Flag it if you "
                             "think the value is wrong.")
    value = check_value(ctx.conn, spec_id, ctx.field("value"))
    if len(value) > 500:
        raise HttpError(400, "value is limited to 500 characters")

    cur = ctx.conn.execute(
        "UPDATE specs SET value=?, confidence='pending', entered_by=?,"
        " updated_at=datetime('now')"
        # Re-check emptiness in the UPDATE itself: two people filling the same
        # blank at once would otherwise have the second silently overwrite the
        # first, which is the destructive case this endpoint refuses.
        " WHERE id=? AND (value IS NULL OR value='')",
        (value, ctx.user["id"], spec_id))
    if not cur.rowcount:
        ctx.conn.rollback()
        raise HttpError(409, "somebody filled this in first — reload to see it")
    ctx.conn.commit()
    return {"ok": True, "value": value, "confidence": "pending"}


@route("PATCH", r"/api/specs/(\d+)", role="manager")
def edit_spec(ctx):
    """The manager's direct edit: confirm a community value, or correct it.

    Confirming means raising the confidence off 'pending', which is also what
    takes it out of the review queue — the queue is derived from confidence
    rather than a separate flag that could drift out of step with it.
    """
    spec_id = int(ctx.params[0])
    spec = one(ctx.conn.execute("SELECT * FROM specs WHERE id=?", (spec_id,)))
    if not spec:
        raise HttpError(404, "spec not found")
    require_manages(ctx.conn, ctx.user, spec["bike_id"])

    confidence = ctx.body.get("confidence", spec["confidence"])
    if confidence not in ("confirmed", "mfr", "pending"):
        raise HttpError(400, "unknown confidence")
    value = check_value(ctx.conn, spec_id, ctx.body.get("value", spec["value"]))

    # entered_by means "who supplied this value", so it only moves when the
    # value actually changes. Confirming somebody else's contribution must not
    # quietly reassign it to the confirmer — that strips the credit from the
    # rider who did the work and shifts it onto the manager's profile stats.
    changed = value != spec["value"]
    entered_by = ctx.user["id"] if changed else spec["entered_by"]

    ctx.conn.execute(
        "UPDATE specs SET value=?, confidence=?, entered_by=?,"
        " updated_at=datetime('now') WHERE id=?",
        (value, confidence, entered_by, spec_id))
    ctx.conn.commit()
    return {"ok": True, "value_changed": changed}


@route("PATCH", r"/api/specs/(\d+)/type", role="manager")
def set_spec_type(ctx):
    """Mark one spec on your bike as Fixed — or clear the mark.

    Fixed means "one correct value, and I am the one who sets it": no
    alternates, no community value submissions. That is a judgement about a
    particular machine, so it is stored per bike. Setting it on spec_fields
    would change the field for every bike in the catalog, which is admin's
    call, not a manager's.

    spec_type = null clears the override and the field falls back to whatever
    the Spec Tree says, rather than being stuck at the manager's last choice.
    """
    spec_id = int(ctx.params[0])
    spec = one(ctx.conn.execute(
        "SELECT s.bike_id, s.field_key, f.spec_type AS field_type,"
        "       COALESCE(s.spec_type, f.spec_type) AS effective_type"
        " FROM specs s JOIN spec_fields f ON f.field_key = s.field_key"
        " WHERE s.id = ?", (spec_id,)))
    if not spec:
        raise HttpError(404, "spec not found")
    require_manages(ctx.conn, ctx.user, spec["bike_id"])

    new_type = ctx.body.get("spec_type", "__missing__")
    if new_type == "__missing__":
        raise HttpError(400, "spec_type is required (null clears the override)")
    if new_type is not None and new_type not in ("fixed", "pref", "community"):
        raise HttpError(400, "spec_type must be fixed, pref, community, or null")

    ctx.conn.execute("UPDATE specs SET spec_type=?, updated_at=datetime('now')"
                     " WHERE id=?", (new_type, spec_id))
    ctx.conn.commit()
    effective = new_type or spec["field_type"]
    return {"ok": True, "spec_type": effective,
            "overridden": new_type is not None,
            "field_default": spec["field_type"]}


@route("POST", r"/api/bikes/(\d+)/header", role="manager")
def pin_header_spec(ctx):
    """Lift one spec into this bike's hero.

    Per bike, not by moving the field into General. General is a Spec Tree
    property and lands on all 261 bikes at once; a manager is scoped to the
    bikes assigned to them, so reshaping one hero must not reshape the rest.
    Same reasoning as the per-bike Fixed tag.

    Pins sit on top of General rather than replacing it, so the hero never ends
    up emptier than the site-wide default.
    """
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)

    field_key = (ctx.body.get("field_key") or "").strip()
    if not field_key:
        raise HttpError(400, "field_key is required")

    # The spec has to exist ON THIS BIKE. Pinning by field_key alone would let
    # a hero advertise a field the bike does not carry.
    spec = one(ctx.conn.execute(
        "SELECT s.id, f.label, f.category FROM specs s"
        " JOIN spec_fields f ON f.field_key = s.field_key"
        " WHERE s.bike_id = ? AND s.field_key = ?", (bike_id, field_key)))
    if not spec:
        raise HttpError(404, "this bike has no such spec")

    if spec["category"] == "General":
        # A General field is in the header by Spec Tree rule, so the only thing
        # a manager can do to it here is take it OUT of this one bike's header.
        # Pinning it would be a no-op, and asking to pin it is almost always a
        # misread of the control, so say what is possible instead.
        if not ctx.body.get("hidden"):
            raise HttpError(409, "General specs are in every bike's header"
                                 " already — send hidden: true to take this"
                                 " one out of this bike's header")
        ctx.conn.execute(
            "INSERT INTO bike_header_specs"
            " (bike_id, field_key, sort_order, hidden, pinned_by)"
            " VALUES (?,?,0,1,?)"
            " ON CONFLICT(bike_id, field_key) DO UPDATE SET"
            "   hidden = 1, pinned_by = excluded.pinned_by",
            (bike_id, field_key, ctx.user["id"]))
        ctx.conn.commit()
        return {"ok": True, "field_key": field_key, "label": spec["label"],
                "in_header": False, "hidden": True}

    # Shown in the header INSTEAD of its section, rather than as well. The
    # quicklist carries no vote, flag or request controls, so this trades those
    # away — worth it for a headline figure nobody argues about, and the
    # manager is the one who knows which of their specs those are.
    hide_below = bool(ctx.body.get("hide_below"))

    nxt = ctx.conn.execute(
        "SELECT COALESCE(MAX(sort_order), 0) + 10 FROM bike_header_specs"
        " WHERE bike_id = ?", (bike_id,)).fetchone()[0]
    # Re-pinning an already-pinned spec is how the choice gets changed, so this
    # updates rather than ignores.
    ctx.conn.execute(
        "INSERT INTO bike_header_specs"
        " (bike_id, field_key, sort_order, hide_below, hidden, pinned_by)"
        " VALUES (?,?,?,?,0,?)"
        " ON CONFLICT(bike_id, field_key) DO UPDATE SET"
        "   hide_below = excluded.hide_below, hidden = 0,"
        "   pinned_by = excluded.pinned_by",
        (bike_id, field_key, nxt, 1 if hide_below else 0, ctx.user["id"]))
    ctx.conn.commit()
    return {"ok": True, "field_key": field_key, "label": spec["label"],
            "in_header": True, "hide_below": hide_below}


@route("DELETE", r"/api/bikes/(\d+)/header/([a-z0-9_]+)", role="manager")
def unpin_header_spec(ctx):
    """Take a pinned spec back out of this bike's hero.

    Only ever removes a pin. A General field cannot be unpinned here because it
    was never pinned — it is in the hero by Spec Tree decision, and undoing that
    from one bike's page is exactly the site-wide reach this stays clear of.
    """
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)
    field_key = ctx.params[1]

    cur = ctx.conn.execute(
        "DELETE FROM bike_header_specs WHERE bike_id=? AND field_key=?",
        (bike_id, field_key))
    ctx.conn.commit()
    if cur.rowcount == 0:
        raise HttpError(404, "that spec is not pinned to this bike's hero")
    return {"ok": True, "field_key": field_key, "in_header": False}


@route("POST", r"/api/specs/(\d+)/split-year", role="manager")
def split_spec_year(ctx):
    """Give one spec a different value from a given model year onward.

    The bike is not split. A tank that grew in 1978 is the same machine with a
    bigger tank -- same engine, same frame -- and splitting the bike would
    duplicate the twenty-eight specs that did not change to vary the two that
    did. Splitting the BIKE is for when the machine itself changed.

    The existing row keeps the earlier years; a new row carries `at_year`
    onward with the same value copied in, because the manager is about to
    correct it and starting from what it was beats starting from blank.
    """
    spec_id = int(ctx.params[0])
    spec = one(ctx.conn.execute(
        "SELECT s.*, f.label, b.year_start, b.year_end"
        " FROM specs s JOIN spec_fields f ON f.field_key = s.field_key"
        " JOIN bikes b ON b.id = s.bike_id WHERE s.id=?", (spec_id,)))
    if not spec:
        raise HttpError(404, "spec not found")
    require_manages(ctx.conn, ctx.user, spec["bike_id"])

    # An open-ended bike has no last year to split against.
    last = spec["year_to"] if spec["year_to"] is not None else spec["year_end"]
    first = spec["year_from"] if spec["year_from"] is not None else spec["year_start"]
    if last is None:
        raise HttpError(409, "this bike has no end year, so there is no range"
                             " to split — set its years first")

    try:
        at = int(ctx.field("at_year"))
    except (TypeError, ValueError):
        raise HttpError(400, "at_year must be a year")
    if not first < at <= last:
        raise HttpError(400, f"pick a year after {first} and no later than"
                             f" {last} — {at} leaves nothing on one side")

    ctx.conn.execute(
        "UPDATE specs SET year_from=?, year_to=?, updated_at=datetime('now')"
        " WHERE id=?", (first, at - 1, spec_id))
    cur = ctx.conn.execute(
        "INSERT INTO specs (bike_id, field_key, value, confidence, spec_type,"
        " tools, entered_by, year_from, year_to)"
        " VALUES (?,?,?,?,?,?,?,?,?)",
        (spec["bike_id"], spec["field_key"], spec["value"], spec["confidence"],
         spec["spec_type"], spec["tools"], ctx.user["id"], at, last))
    ctx.conn.commit()
    return {"ok": True, "label": spec["label"],
            "earlier": {"id": spec_id, "year_from": first, "year_to": at - 1},
            "later": {"id": cur.lastrowid, "year_from": at, "year_to": last}}


@route("POST", r"/api/specs/(\d+)/merge-years", role="manager")
def merge_spec_years(ctx):
    """Undo a year split: this variant's value becomes the whole bike's again.

    Destructive in one direction -- the other variants' values are discarded --
    so the values being dropped come back in the response for the console to
    name before it asks.
    """
    spec_id = int(ctx.params[0])
    spec = one(ctx.conn.execute(
        "SELECT s.*, f.label FROM specs s"
        " JOIN spec_fields f ON f.field_key = s.field_key WHERE s.id=?",
        (spec_id,)))
    if not spec:
        raise HttpError(404, "spec not found")
    require_manages(ctx.conn, ctx.user, spec["bike_id"])
    if spec["year_from"] is None:
        raise HttpError(409, "this spec already covers every year")

    others = rows(ctx.conn.execute(
        "SELECT id, value, year_from, year_to FROM specs"
        " WHERE bike_id=? AND field_key=? AND id<>?",
        (spec["bike_id"], spec["field_key"], spec_id)))
    if not others:
        # Nothing to merge with; just widen it back out.
        ctx.conn.execute(
            "UPDATE specs SET year_from=NULL, year_to=NULL,"
            " updated_at=datetime('now') WHERE id=?", (spec_id,))
        ctx.conn.commit()
        return {"ok": True, "label": spec["label"], "dropped": []}

    if not ctx.body.get("force"):
        raise HttpError(409, "merging discards the other year ranges for this"
                             " spec — confirm to go ahead")

    # Alternates, votes, flags and requests on the discarded rows go with them,
    # which is why this asks first.
    ctx.conn.executemany("DELETE FROM specs WHERE id=?",
                         [(o["id"],) for o in others])
    ctx.conn.execute(
        "UPDATE specs SET year_from=NULL, year_to=NULL,"
        " updated_at=datetime('now') WHERE id=?", (spec_id,))
    ctx.conn.commit()
    return {"ok": True, "label": spec["label"],
            "kept": spec["value"],
            "dropped": [{"value": o["value"], "year_from": o["year_from"],
                         "year_to": o["year_to"]} for o in others]}


@route("POST", r"/api/specs/(\d+)/pause", role="manager")
def toggle_spec_pause(ctx):
    """Take one spec offline, or put it back online.

    The same hide-without-destroying idea the tools and links already use,
    applied to the value itself. A spec goes offline when it might be wrong —
    a flag has come in and nobody has checked it yet — and leaving it up means
    riders keep reading a number as fact while it is in doubt. Deleting it
    would take the value, its alternates and their votes with it.

    Per bike and per spec, so pausing a torque figure on one machine says
    nothing about the same field on the other 260.
    """
    spec_id = int(ctx.params[0])
    spec = one(ctx.conn.execute(
        "SELECT s.id, s.bike_id, s.paused, f.label"
        " FROM specs s JOIN spec_fields f ON f.field_key = s.field_key"
        " WHERE s.id = ?", (spec_id,)))
    if not spec:
        raise HttpError(404, "spec not found")
    require_manages(ctx.conn, ctx.user, spec["bike_id"])

    # Explicit when given, toggle when not, so the button works either way and
    # two managers clicking at once cannot land on opposite states.
    want = ctx.body.get("paused")
    new = (0 if spec["paused"] else 1) if want is None else (1 if want else 0)

    # Resuming clears who paused it and when: those record a spec that is
    # currently offline, not a history of every time one ever was.
    ctx.conn.execute(
        "UPDATE specs SET paused=?, paused_by=?,"
        "  paused_at = CASE WHEN ?=1 THEN datetime('now') ELSE NULL END,"
        "  updated_at = datetime('now')"
        " WHERE id=?",
        (new, ctx.user["id"] if new else None, new, spec_id))
    ctx.conn.commit()
    return {"ok": True, "spec_id": spec_id, "paused": bool(new),
            "label": spec["label"]}


@route("POST", r"/api/specs/(\d+)/vote", role="user")
def toggle_spec_vote(ctx):
    """Upvote the stock value — 'this is right, it fitted mine'."""
    spec_id = int(ctx.params[0])
    refuse_if_paused(ctx.conn, ctx.user, spec_id)
    spec = one(ctx.conn.execute("SELECT value FROM specs WHERE id=?", (spec_id,)))
    if not spec:
        raise HttpError(404, "spec not found")
    if spec["value"] in (None, ""):
        raise HttpError(400, "there is no value here to vote on yet — "
                             "request it, or add one")
    if ctx.conn.execute("SELECT 1 FROM spec_votes WHERE spec_id=? AND user_id=?",
                        (spec_id, ctx.user["id"])).fetchone():
        ctx.conn.execute("DELETE FROM spec_votes WHERE spec_id=? AND user_id=?",
                         (spec_id, ctx.user["id"]))
        voted = False
    else:
        ctx.conn.execute("INSERT INTO spec_votes (spec_id, user_id) VALUES (?,?)",
                         (spec_id, ctx.user["id"]))
        voted = True
    ctx.conn.commit()
    votes = ctx.conn.execute(
        "SELECT votes FROM spec_vote_counts WHERE spec_id=?", (spec_id,)).fetchone()[0]
    return {"voted": voted, "votes": votes}


@route("POST", r"/api/specs/(\d+)/request", role="user")
def toggle_spec_request(ctx):
    """"I want this one filled in." Only meaningful on a gap — once a value
    exists the request is answered, so asking again would just be noise."""
    spec_id = int(ctx.params[0])
    refuse_if_paused(ctx.conn, ctx.user, spec_id)
    spec = one(ctx.conn.execute("SELECT value FROM specs WHERE id=?", (spec_id,)))
    if not spec:
        raise HttpError(404, "spec not found")
    if spec["value"] not in (None, ""):
        raise HttpError(400, "this spec already has a value — "
                             "flag it if you think it is wrong")
    if ctx.conn.execute("SELECT 1 FROM spec_requests WHERE spec_id=? AND user_id=?",
                        (spec_id, ctx.user["id"])).fetchone():
        ctx.conn.execute("DELETE FROM spec_requests WHERE spec_id=? AND user_id=?",
                         (spec_id, ctx.user["id"]))
        requested = False
    else:
        ctx.conn.execute("INSERT INTO spec_requests (spec_id, user_id) VALUES (?,?)",
                         (spec_id, ctx.user["id"]))
        requested = True
    ctx.conn.commit()
    count = ctx.conn.execute(
        "SELECT requests FROM spec_request_counts WHERE spec_id=?", (spec_id,)).fetchone()[0]
    return {"requested": requested, "requests": count}


@route("POST", r"/api/alternates/(\d+)/flag", role="user")
def flag_alternate(ctx):
    """Flag one alternate rather than the spec. Recorded on the same table as a
    stock-value flag, distinguished by alternate_id, so the manager's queue is
    still one query and one place to work."""
    alt_id = int(ctx.params[0])
    alt = one(ctx.conn.execute(
        "SELECT spec_id FROM spec_alternates WHERE id=?", (alt_id,)))
    if not alt:
        raise HttpError(404, "alternate not found")
    reason = ctx.field("reason")
    if reason not in ("irrelevant", "incorrect", "inappropriate", "other"):
        raise HttpError(400, "unknown reason")
    detail = ctx.field("detail", required=False)
    if detail and len(detail) > 150:
        raise HttpError(400, "detail is limited to 150 characters")
    if ctx.conn.execute(
            "SELECT 1 FROM value_flags WHERE alternate_id=? AND flagged_by=?"
            " AND status='open'", (alt_id, ctx.user["id"])).fetchone():
        raise HttpError(409, "you have already flagged this alternate")
    cur = ctx.conn.execute(
        "INSERT INTO value_flags (spec_id, alternate_id, flagged_by, reason, detail)"
        " VALUES (?,?,?,?,?)",
        (alt["spec_id"], alt_id, ctx.user["id"], reason, detail))
    ctx.conn.commit()
    return {"id": cur.lastrowid}


@route("POST", r"/api/alternates/(\d+)/vote", role="user")
def toggle_alternate_vote(ctx):
    alt_id = int(ctx.params[0])
    if not ctx.conn.execute("SELECT 1 FROM spec_alternates WHERE id=?", (alt_id,)).fetchone():
        raise HttpError(404, "alternate not found")
    existing = ctx.conn.execute(
        "SELECT 1 FROM alternate_votes WHERE alternate_id=? AND user_id=?",
        (alt_id, ctx.user["id"])).fetchone()
    if existing:
        ctx.conn.execute(
            "DELETE FROM alternate_votes WHERE alternate_id=? AND user_id=?",
            (alt_id, ctx.user["id"]))
        voted = False
    else:
        ctx.conn.execute(
            "INSERT INTO alternate_votes (alternate_id, user_id) VALUES (?,?)",
            (alt_id, ctx.user["id"]))
        voted = True
    ctx.conn.commit()
    votes = ctx.conn.execute(
        "SELECT votes FROM alternate_vote_counts WHERE alternate_id=?",
        (alt_id,)).fetchone()[0]
    return {"voted": voted, "votes": votes}


@route("POST", r"/api/specs/(\d+)/flags", role="user")
def flag_spec(ctx):
    spec_id = int(ctx.params[0])
    refuse_if_paused(ctx.conn, ctx.user, spec_id)
    if not ctx.conn.execute("SELECT 1 FROM specs WHERE id=?", (spec_id,)).fetchone():
        raise HttpError(404, "spec not found")
    reason = ctx.field("reason")
    if reason not in ("irrelevant", "incorrect", "inappropriate", "other"):
        raise HttpError(400, "unknown reason")
    detail = ctx.field("detail", required=False)
    if detail and len(detail) > 150:
        raise HttpError(400, "detail is limited to 150 characters")
    # One open flag per person per value, matching the alternate endpoint.
    # Without this the same rider could raise the same complaint repeatedly and
    # the count would read as several people disagreeing.
    if ctx.conn.execute(
            "SELECT 1 FROM value_flags WHERE spec_id=? AND alternate_id IS NULL"
            " AND flagged_by=? AND status='open'",
            (spec_id, ctx.user["id"])).fetchone():
        raise HttpError(409, "you have already flagged this value")
    cur = ctx.conn.execute(
        "INSERT INTO value_flags (spec_id, flagged_by, reason, detail)"
        " VALUES (?,?,?,?)", (spec_id, ctx.user["id"], reason, detail))
    ctx.conn.commit()
    return {"id": cur.lastrowid}


@route("DELETE", r"/api/flags/(\d+)", role="user")
def withdraw_flag(ctx):
    """'Flagged by mistake' — only your own, and only while still open."""
    flag_id = int(ctx.params[0])
    f = one(ctx.conn.execute("SELECT * FROM value_flags WHERE id=?", (flag_id,)))
    if not f:
        raise HttpError(404, "flag not found")
    if f["flagged_by"] != ctx.user["id"]:
        raise HttpError(403, "not your flag")
    if f["status"] != "open":
        raise HttpError(400, "this flag has already been resolved")
    ctx.conn.execute("DELETE FROM value_flags WHERE id=?", (flag_id,))
    ctx.conn.commit()
    return {"ok": True}


# ===========================================================================
# MANAGER DASHBOARD
# ===========================================================================
def _managed_bike_ids(conn, user):
    if user["role"] == "admin":
        return [r["id"] for r in rows(conn.execute("SELECT id FROM bikes"))]
    return [r["bike_id"] for r in rows(conn.execute(
        "SELECT bike_id FROM bike_managers WHERE user_id=?", (user["id"],)))]


@route("GET", r"/api/manager/bikes", role="manager")
def manager_bikes(ctx):
    return {"bikes": rows(ctx.conn.execute(
        "SELECT d.*, p.fields_triggered, p.specs_filled, p.specs_needed,"
        " m.specialty,"
        " (SELECT COUNT(*) FROM value_flags vf JOIN specs s ON s.id=vf.spec_id"
        "   WHERE s.bike_id=d.bike_id AND vf.status='open') AS open_flags"
        " FROM bike_managers m"
        " JOIN bike_display d ON d.bike_id = m.bike_id"
        " JOIN bike_spec_progress p ON p.bike_id = m.bike_id"
        " WHERE m.user_id = ? ORDER BY d.display_name", (ctx.user["id"],)))}


@route("GET", r"/api/manager/summary", role="manager")
def manager_summary(ctx):
    ids = _managed_bike_ids(ctx.conn, ctx.user)
    if not ids:
        return {"bikes_managed": 0, "specs_filled": 0, "specs_needed": 0,
                "open_flags": 0, "not_sure_pending": 0, "proposals": 0}
    ph = ",".join("?" * len(ids))
    agg = one(ctx.conn.execute(
        f"SELECT COALESCE(SUM(specs_filled),0) AS specs_filled,"
        f" COALESCE(SUM(specs_needed),0) AS specs_needed"
        f" FROM bike_spec_progress WHERE bike_id IN ({ph})", ids))
    open_flags = ctx.conn.execute(
        f"SELECT COUNT(*) FROM value_flags vf JOIN specs s ON s.id=vf.spec_id"
        f" WHERE vf.status='open' AND s.bike_id IN ({ph})", ids).fetchone()[0]
    not_sure = ctx.conn.execute(
        "SELECT COUNT(*) FROM not_sure_answers WHERE submitted_by=? AND status='pending'",
        (ctx.user["id"],)).fetchone()[0]
    proposals = ctx.conn.execute(
        "SELECT COUNT(*) FROM branch_proposals WHERE proposed_by=?",
        (ctx.user["id"],)).fetchone()[0]
    submissions = ctx.conn.execute(
        f"SELECT COUNT(*) FROM specs s WHERE s.bike_id IN ({ph})"
        f" AND s.value IS NOT NULL AND s.value <> '' AND s.confidence='pending'"
        f" AND s.entered_by IS NOT NULL"
        f" AND NOT EXISTS (SELECT 1 FROM bike_managers m"
        f"                 WHERE m.bike_id = s.bike_id AND m.user_id = s.entered_by)",
        ids).fetchone()[0]
    requested = ctx.conn.execute(
        f"SELECT COUNT(*) FROM specs s"
        f" JOIN spec_request_counts rc ON rc.spec_id = s.id"
        f" WHERE s.bike_id IN ({ph}) AND (s.value IS NULL OR s.value='')"
        f"   AND rc.requests > 0", ids).fetchone()[0]
    return {"bikes_managed": len(ids), **agg, "open_flags": open_flags,
            "not_sure_pending": not_sure, "proposals": proposals,
            "submissions": submissions, "requested_gaps": requested}


@route("GET", r"/api/manager/flags", role="manager")
def manager_flags(ctx):
    ids = _managed_bike_ids(ctx.conn, ctx.user)
    if not ids:
        return {"flags": []}
    ph = ",".join("?" * len(ids))
    return {"flags": rows(ctx.conn.execute(
        f"SELECT vf.id, vf.reason, vf.detail, vf.created_at, vf.spec_id,"
        # A flag may target the stock value or one alternate. alt_text tells
        # them apart, so a manager is never asked to "fix" a value that is
        # actually somebody's competing suggestion.
        f"       vf.alternate_id, alt.text AS alt_text,"
        f"       f.label AS spec_label, s.value AS current_value, s.bike_id,"
        # So the queue can offer the right actions: whether the spec is already
        # offline, and what kind of value it is, since a wire colour cannot be
        # fixed by typing into a text box.
        f"       s.paused AS spec_offline, f.value_type,"
        f"       d.display_name AS bike_name,"
        f"       fb.id AS flagged_by_id, fb.username AS flagged_by,"
        f"       eb.id AS entered_by_id,"
        f"       COALESCE(eb.username,'—') AS entered_by"
        f" FROM value_flags vf"
        f" JOIN specs s ON s.id = vf.spec_id"
        f" JOIN spec_fields f ON f.field_key = s.field_key"
        f" JOIN bike_display d ON d.bike_id = s.bike_id"
        f" JOIN users fb ON fb.id = vf.flagged_by"
        f" LEFT JOIN users eb ON eb.id = s.entered_by"
        f" LEFT JOIN spec_alternates alt ON alt.id = vf.alternate_id"
        f" WHERE vf.status='open' AND s.bike_id IN ({ph})"
        f" ORDER BY vf.created_at DESC", ids))}


@route("GET", r"/api/manager/submissions", role="manager")
def manager_submissions(ctx):
    """Values the public filled into gaps on your bikes.

    Derived, not a separate queue table: a submission is a spec that has a
    value, is still 'pending', and was entered by somebody who does not manage
    the bike. Confirming it raises the confidence, which is what removes it
    from this list — so the queue cannot drift out of step with the data.
    """
    ids = _managed_bike_ids(ctx.conn, ctx.user)
    if not ids:
        return {"submissions": []}
    ph = ",".join("?" * len(ids))
    return {"submissions": rows(ctx.conn.execute(
        f"SELECT s.id AS spec_id, s.value, s.updated_at, s.bike_id,"
        f"       f.label AS spec_label, f.category, f.spec_type,"
        f"       u.id AS entered_by_id, u.username AS entered_by,"
        f"       d.display_name AS bike_name"
        f" FROM specs s"
        f" JOIN spec_fields f ON f.field_key = s.field_key"
        f" JOIN users u ON u.id = s.entered_by"
        f" JOIN bike_display d ON d.bike_id = s.bike_id"
        f" WHERE s.bike_id IN ({ph})"
        f"   AND s.value IS NOT NULL AND s.value <> ''"
        f"   AND s.confidence = 'pending'"
        f"   AND NOT EXISTS (SELECT 1 FROM bike_managers m"
        f"                   WHERE m.bike_id = s.bike_id AND m.user_id = s.entered_by)"
        f" ORDER BY s.updated_at DESC", ids))}


@route("GET", r"/api/manager/requests", role="manager")
def manager_requests(ctx):
    """Gaps on your bikes, ranked by how many riders asked for them.

    This is the whole point of the request button: 40 empty fields with no
    ordering is a wall, the same 40 with "6 riders asked for this" at the top is
    a to-do list.
    """
    ids = _managed_bike_ids(ctx.conn, ctx.user)
    if not ids:
        return {"requests": []}
    ph = ",".join("?" * len(ids))
    return {"requests": rows(ctx.conn.execute(
        f"SELECT s.id AS spec_id, s.field_key, f.label AS spec_label, f.category,"
        f"       rc.requests, d.display_name AS bike_name, s.bike_id,"
        f"       (SELECT MAX(created_at) FROM spec_requests r WHERE r.spec_id=s.id)"
        f"         AS last_requested"
        f" FROM specs s"
        f" JOIN spec_fields f ON f.field_key = s.field_key"
        f" JOIN spec_request_counts rc ON rc.spec_id = s.id"
        f" JOIN bike_display d ON d.bike_id = s.bike_id"
        f" WHERE s.bike_id IN ({ph})"
        f"   AND (s.value IS NULL OR s.value = '')"
        f"   AND rc.requests > 0"
        f" ORDER BY rc.requests DESC, f.label", ids))}


@route("GET", r"/api/manager/resolved", role="manager")
def manager_resolved(ctx):
    ids = _managed_bike_ids(ctx.conn, ctx.user)
    if not ids:
        return {"resolved": []}
    ph = ",".join("?" * len(ids))
    return {"resolved": rows(ctx.conn.execute(
        f"SELECT vf.id, vf.status AS outcome, vf.old_value, vf.new_value,"
        f"       vf.resolved_at, f.label AS spec_label"
        f" FROM value_flags vf"
        f" JOIN specs s ON s.id = vf.spec_id"
        f" JOIN spec_fields f ON f.field_key = s.field_key"
        f" WHERE vf.status IN ('fixed','dismissed') AND s.bike_id IN ({ph})"
        f" ORDER BY vf.resolved_at DESC LIMIT 50", ids))}


@route("POST", r"/api/flags/(\d+)/fix", role="manager")
def fix_flag(ctx):
    """Set the value directly — no vote. The assigned manager is the expert for
    this bike, which is the entire reason the flag was routed here."""
    flag_id = int(ctx.params[0])
    f = one(ctx.conn.execute(
        "SELECT vf.*, s.bike_id, s.value AS current_value"
        " FROM value_flags vf JOIN specs s ON s.id = vf.spec_id"
        " WHERE vf.id=?", (flag_id,)))
    if not f:
        raise HttpError(404, "flag not found")
    if f["status"] != "open":
        raise HttpError(400, "this flag is already resolved")
    if f["alternate_id"] is not None:
        # This flag is against somebody's alternate, not the stock value.
        # Writing new_value here would overwrite the manual's value with an
        # edit that was never aimed at it.
        raise HttpError(400, "this flag is against an alternate, not the stock "
                             "value — dismiss it, or edit the spec directly")
    require_manages(ctx.conn, ctx.user, f["bike_id"])

    new_value = check_value(ctx.conn, f["spec_id"], ctx.field("new_value"))
    ctx.conn.execute(
        "UPDATE specs SET value=?, entered_by=?, updated_at=datetime('now')"
        " WHERE id=?", (new_value, ctx.user["id"], f["spec_id"]))
    ctx.conn.execute(
        "UPDATE value_flags SET status='fixed', old_value=?, new_value=?,"
        " resolved_by=?, resolved_at=datetime('now') WHERE id=?",
        (f["current_value"], new_value, ctx.user["id"], flag_id))
    ctx.conn.commit()
    return {"ok": True}


@route("POST", r"/api/flags/(\d+)/remove-alternate", role="manager")
def remove_flagged_alternate(ctx):
    """Take down the alternate a flag is about, and close the flag.

    Fixing the stock value is the wrong answer to a flag against somebody's
    competing suggestion — the stock value was never what was complained about.
    Until now that left the manager with nothing to do but dismiss, which
    records "the flag was not valid" about a flag that was.

    Hidden rather than deleted, the way a paused tool or link is: the text and
    its votes survive if the call turns out to be wrong.
    """
    flag_id = int(ctx.params[0])
    f = one(ctx.conn.execute(
        "SELECT vf.*, s.bike_id FROM value_flags vf"
        " JOIN specs s ON s.id = vf.spec_id WHERE vf.id=?", (flag_id,)))
    if not f:
        raise HttpError(404, "flag not found")
    if f["status"] != "open":
        raise HttpError(400, "this flag is already resolved")
    if f["alternate_id"] is None:
        raise HttpError(400, "this flag is against the stock value, not an "
                             "alternate — fix the value instead")
    require_manages(ctx.conn, ctx.user, f["bike_id"])

    alt = one(ctx.conn.execute("SELECT text FROM spec_alternates WHERE id=?",
                               (f["alternate_id"],)))
    ctx.conn.execute("UPDATE spec_alternates SET paused=1 WHERE id=?",
                     (f["alternate_id"],))
    ctx.conn.execute(
        "UPDATE value_flags SET status='fixed', old_value=?,"
        " new_value='(alternate hidden)', resolved_by=?,"
        " resolved_at=datetime('now') WHERE id=?",
        (alt["text"] if alt else None, ctx.user["id"], flag_id))
    ctx.conn.commit()
    return {"ok": True, "hidden": alt["text"] if alt else None}


@route("POST", r"/api/flags/(\d+)/offline", role="manager")
def take_flagged_spec_offline(ctx):
    """Take the spec offline from the flag queue, where the triage happens.

    A flag saying a value is wrong is exactly when it should stop being read as
    fact, and the manager is looking at the queue rather than the bike page. The
    flag stays OPEN: going offline buys time to check, it does not decide
    anything, and closing it here would lose the thing still to be done.
    """
    flag_id = int(ctx.params[0])
    f = one(ctx.conn.execute(
        "SELECT vf.*, s.bike_id, f.label FROM value_flags vf"
        " JOIN specs s ON s.id = vf.spec_id"
        " JOIN spec_fields f ON f.field_key = s.field_key"
        " WHERE vf.id=?", (flag_id,)))
    if not f:
        raise HttpError(404, "flag not found")
    require_manages(ctx.conn, ctx.user, f["bike_id"])

    want = ctx.body.get("offline", True)
    paused = 1 if want else 0
    ctx.conn.execute(
        "UPDATE specs SET paused=?, paused_by=?,"
        "  paused_at = CASE WHEN ?=1 THEN datetime('now') ELSE NULL END,"
        "  updated_at = datetime('now') WHERE id=?",
        (paused, ctx.user["id"] if paused else None, paused, f["spec_id"]))
    ctx.conn.commit()
    return {"ok": True, "spec_id": f["spec_id"], "label": f["label"],
            "offline": bool(paused)}


@route("POST", r"/api/flags/(\d+)/dismiss", role="manager")
def dismiss_flag(ctx):
    """Tracked separately from a fix, so the flagger's history reflects which
    of their flags led to a real change and which did not."""
    flag_id = int(ctx.params[0])
    f = one(ctx.conn.execute(
        "SELECT vf.*, s.bike_id, s.value AS current_value"
        " FROM value_flags vf JOIN specs s ON s.id = vf.spec_id"
        " WHERE vf.id=?", (flag_id,)))
    if not f:
        raise HttpError(404, "flag not found")
    if f["status"] != "open":
        raise HttpError(400, "this flag is already resolved")
    require_manages(ctx.conn, ctx.user, f["bike_id"])
    ctx.conn.execute(
        "UPDATE value_flags SET status='dismissed', old_value=?, resolved_by=?,"
        " resolved_at=datetime('now') WHERE id=?",
        (f["current_value"], ctx.user["id"], flag_id))
    ctx.conn.commit()
    return {"ok": True}


@route("POST", r"/api/flags/(\d+)/messages", role="manager")
def message_flagger(ctx):
    flag_id = int(ctx.params[0])
    f = one(ctx.conn.execute(
        "SELECT vf.*, s.bike_id FROM value_flags vf"
        " JOIN specs s ON s.id=vf.spec_id WHERE vf.id=?", (flag_id,)))
    if not f:
        raise HttpError(404, "flag not found")
    require_manages(ctx.conn, ctx.user, f["bike_id"])

    # Who the manager needs is not always the flagger. "Was this on a later
    # production run?" goes to the rider who raised it; "this field is wrong
    # for the whole platform" goes to an admin, and having to leave the queue
    # to find one is how that conversation does not happen.
    to = ctx.body.get("to", "flagger")
    if to == "flagger":
        recipient = f["flagged_by"]
    elif to == "admin":
        row = one(ctx.conn.execute(
            "SELECT id FROM users WHERE role='admin' AND suspended=0"
            " ORDER BY id LIMIT 1"))
        if not row:
            raise HttpError(409, "there is no admin to write to")
        recipient = row["id"]
    else:
        raise HttpError(400, "to must be 'flagger' or 'admin'")

    if recipient == ctx.user["id"]:
        raise HttpError(400, "that is you — pick the other recipient")

    cur = ctx.conn.execute(
        "INSERT INTO flag_messages (value_flag_id, from_user, to_user, body)"
        " VALUES (?,?,?,?)",
        (flag_id, ctx.user["id"], recipient, ctx.field("body")))
    ctx.conn.commit()
    return {"id": cur.lastrowid, "to": to}


@route("GET", r"/api/manager/not-sure", role="manager")
def manager_not_sure(ctx):
    return {"items": rows(ctx.conn.execute(
        "SELECT n.id, n.question_text, n.status, n.created_at, n.admin_note,"
        " d.display_name AS bike_name"
        " FROM not_sure_answers n JOIN bike_display d ON d.bike_id=n.bike_id"
        " WHERE n.submitted_by=? ORDER BY n.created_at DESC",
        (ctx.user["id"],)))}


@route("GET", r"/api/manager/proposals", role="manager")
def manager_proposals(ctx):
    return {"proposals": rows(ctx.conn.execute(
        "SELECT id, field_name, category, status, reasoning, admin_note, created_at"
        " FROM branch_proposals WHERE proposed_by=? ORDER BY created_at DESC",
        (ctx.user["id"],)))}


@route("POST", r"/api/proposals", role="manager")
def create_proposal(ctx):
    cur = ctx.conn.execute(
        "INSERT INTO branch_proposals (field_name, category, bike_id,"
        " proposed_by, reasoning) VALUES (?,?,?,?,?)",
        (ctx.field("field_name"), ctx.field("category"),
         ctx.body.get("bike_id"), ctx.user["id"], ctx.field("reasoning")))
    ctx.conn.commit()
    return {"id": cur.lastrowid}


# ===========================================================================
# USER PROFILES
# ===========================================================================
@route("GET", r"/api/users/(\d+)/profile")
def user_profile(ctx):
    p = one(ctx.conn.execute(
        "SELECT * FROM user_profile_stats WHERE user_id=?", (int(ctx.params[0]),)))
    if not p:
        raise HttpError(404, "user not found")
    return p


@route("POST", r"/api/users/(\d+)/flags", role="user")
def flag_user(ctx):
    target = int(ctx.params[0])
    if target == ctx.user["id"]:
        raise HttpError(400, "you cannot flag yourself")
    if not ctx.conn.execute("SELECT 1 FROM users WHERE id=?", (target,)).fetchone():
        raise HttpError(404, "user not found")
    reason = ctx.field("reason")
    if reason not in ("spam", "harassment", "bad-faith", "fraud",
                      "inappropriate", "other"):
        raise HttpError(400, "unknown reason")
    detail = ctx.field("detail", required=False)
    if detail and len(detail) > 150:
        raise HttpError(400, "detail is limited to 150 characters")
    cur = ctx.conn.execute(
        "INSERT INTO user_flags (flagged_user, flagged_by, reason, detail)"
        " VALUES (?,?,?,?)", (target, ctx.user["id"], reason, detail))
    ctx.conn.commit()
    return {"id": cur.lastrowid}


# ===========================================================================
# ENRICHMENT — tools and links on a (bike, field)
# ===========================================================================
@route("GET", r"/api/bikes/(\d+)/fields/([a-z0-9_]+)/enrichment")
def get_enrichment(ctx):
    bike_id, field_key = int(ctx.params[0]), ctx.params[1]
    uid = ctx.user["id"] if ctx.user else -1
    is_manager = bool(ctx.user) and manages_bike(ctx.conn, ctx.user, bike_id)

    # A paused entry stays visible to the manager who paused it (they need to
    # unpause it) but is hidden from everyone else.
    pause_clause = "" if is_manager else " AND paused = 0"

    spec = one(ctx.conn.execute(
        "SELECT s.id, s.value, s.tools, s.confidence, f.label, f.category"
        " FROM specs s JOIN spec_fields f ON f.field_key=s.field_key"
        " WHERE s.bike_id=? AND s.field_key=?", (bike_id, field_key)))
    if not spec:
        raise HttpError(404, "no such spec on this bike")

    return {
        "spec": spec,
        "is_manager": is_manager,
        "tools": rows(ctx.conn.execute(
            f"SELECT t.id, t.text, t.paused, u.username AS added_by"
            f" FROM spec_tools t LEFT JOIN users u ON u.id=t.added_by"
            f" WHERE t.bike_id=? AND t.field_key=?{pause_clause}"
            f" ORDER BY t.id", (bike_id, field_key))),
        "links": rows(ctx.conn.execute(
            f"SELECT l.id, l.link_type, l.title, l.url, l.paused, c.votes,"
            f"  u.username AS added_by,"
            f"  EXISTS(SELECT 1 FROM link_votes v WHERE v.link_id=l.id AND v.user_id=?) AS my_vote,"
            f"  EXISTS(SELECT 1 FROM link_flags g WHERE g.link_id=l.id AND g.flagged_by=?) AS my_flag,"
            f"  (SELECT COUNT(*) FROM link_flags g WHERE g.link_id=l.id AND g.status='open') AS flags"
            f" FROM spec_links l"
            f" JOIN link_vote_counts c ON c.link_id=l.id"
            f" LEFT JOIN users u ON u.id=l.added_by"
            f" WHERE l.bike_id=? AND l.field_key=?{pause_clause}"
            f" ORDER BY c.votes DESC, l.id", (uid, uid, bike_id, field_key))),
    }


@route("POST", r"/api/bikes/(\d+)/fields/([a-z0-9_]+)/tools", role="user")
def add_tool(ctx):
    bike_id, field_key = int(ctx.params[0]), ctx.params[1]
    try:
        cur = ctx.conn.execute(
            "INSERT INTO spec_tools (bike_id, field_key, text, added_by)"
            " VALUES (?,?,?,?)",
            (bike_id, field_key, ctx.field("text"), ctx.user["id"]))
    except sqlite3.IntegrityError:
        raise HttpError(409, "that tool is already listed")
    ctx.conn.commit()
    return {"id": cur.lastrowid}


@route("POST", r"/api/bikes/(\d+)/fields/([a-z0-9_]+)/links", role="user")
def add_link(ctx):
    bike_id, field_key = int(ctx.params[0]), ctx.params[1]
    link_type = ctx.field("link_type")
    if link_type not in ("yt", "forum", "doc", "other"):
        raise HttpError(400, "unknown link type")
    url = ctx.field("url")
    if not re.match(r"^https?://", url):
        raise HttpError(400, "link must start with http:// or https://")
    try:
        cur = ctx.conn.execute(
            "INSERT INTO spec_links (bike_id, field_key, link_type, title, url,"
            " added_by) VALUES (?,?,?,?,?,?)",
            (bike_id, field_key, link_type, ctx.field("title"), url,
             ctx.user["id"]))
    except sqlite3.IntegrityError:
        raise HttpError(409, "that link is already listed")
    ctx.conn.commit()
    return {"id": cur.lastrowid}


@route("POST", r"/api/links/(\d+)/vote", role="user")
def toggle_link_vote(ctx):
    link_id = int(ctx.params[0])
    if not ctx.conn.execute("SELECT 1 FROM spec_links WHERE id=?", (link_id,)).fetchone():
        raise HttpError(404, "link not found")
    if ctx.conn.execute("SELECT 1 FROM link_votes WHERE link_id=? AND user_id=?",
                        (link_id, ctx.user["id"])).fetchone():
        ctx.conn.execute("DELETE FROM link_votes WHERE link_id=? AND user_id=?",
                         (link_id, ctx.user["id"]))
        voted = False
    else:
        ctx.conn.execute("INSERT INTO link_votes (link_id, user_id) VALUES (?,?)",
                         (link_id, ctx.user["id"]))
        voted = True
    ctx.conn.commit()
    votes = ctx.conn.execute(
        "SELECT votes FROM link_vote_counts WHERE link_id=?", (link_id,)).fetchone()[0]
    return {"voted": voted, "votes": votes}


@route("POST", r"/api/links/(\d+)/flag", role="user")
def flag_link(ctx):
    link_id = int(ctx.params[0])
    detail = ctx.field("detail", required=False)
    if detail and len(detail) > 150:
        raise HttpError(400, "detail is limited to 150 characters")
    try:
        ctx.conn.execute(
            "INSERT INTO link_flags (link_id, flagged_by, reason, detail)"
            " VALUES (?,?,?,?)",
            (link_id, ctx.user["id"], ctx.field("reason"), detail))
    except sqlite3.IntegrityError:
        raise HttpError(409, "you have already flagged this link")
    ctx.conn.commit()
    return {"ok": True}


@route("DELETE", r"/api/links/(\d+)/flag", role="user")
def unflag_link(ctx):
    """The 'flagged by mistake' control."""
    ctx.conn.execute("DELETE FROM link_flags WHERE link_id=? AND flagged_by=?",
                     (int(ctx.params[0]), ctx.user["id"]))
    ctx.conn.commit()
    return {"ok": True}


@route("POST", r"/api/(tools|links)/(\d+)/pause", role="manager")
def toggle_pause(ctx):
    kind, item_id = ctx.params[0], int(ctx.params[1])
    table = "spec_tools" if kind == "tools" else "spec_links"
    row = one(ctx.conn.execute(f"SELECT bike_id, paused FROM {table} WHERE id=?", (item_id,)))
    if not row:
        raise HttpError(404, "not found")
    require_manages(ctx.conn, ctx.user, row["bike_id"])
    new = 0 if row["paused"] else 1
    ctx.conn.execute(f"UPDATE {table} SET paused=? WHERE id=?", (new, item_id))
    ctx.conn.commit()
    return {"paused": bool(new)}


# ===========================================================================
# GARAGE + SERVICE LOG
# ===========================================================================
def _interval_miles(conn, bike_id, task):
    """Read the interval from the spec sheet, falling back to the task default.

    Reading it from the spec is the point: correct the oil-change interval on
    the spec page and every rider's next-due date moves with it, instead of the
    task table quietly holding a stale copy.
    """
    if task["interval_field_key"]:
        row = conn.execute(
            "SELECT value FROM specs WHERE bike_id=? AND field_key=?",
            (bike_id, task["interval_field_key"])).fetchone()
        if row and row[0]:
            m = re.search(r"([\d,]+)\s*mi\b", row[0], re.I)
            if m:
                return int(m.group(1).replace(",", ""))
    return task["default_interval_miles"]


@route("GET", r"/api/garage", role="user")
def get_garage(ctx):
    return {"garage": rows(ctx.conn.execute(
        "SELECT ub.id, ub.nickname, ub.mileage, y.year, y.id AS bike_year_id,"
        " d.bike_id, d.display_name"
        " FROM user_bikes ub"
        " JOIN bike_years y ON y.id = ub.bike_year_id"
        " JOIN bike_display d ON d.bike_id = y.bike_id"
        " WHERE ub.user_id=? ORDER BY ub.id", (ctx.user["id"],)))}


@route("POST", r"/api/garage", role="user")
def add_to_garage(ctx):
    bike_year_id = ctx.field("bike_year_id")
    if not ctx.conn.execute("SELECT 1 FROM bike_years WHERE id=?", (bike_year_id,)).fetchone():
        raise HttpError(404, "no such model year")
    cur = ctx.conn.execute(
        "INSERT INTO user_bikes (user_id, bike_year_id, nickname, mileage)"
        " VALUES (?,?,?,?)",
        (ctx.user["id"], bike_year_id, ctx.body.get("nickname"),
         ctx.body.get("mileage")))
    ctx.conn.commit()
    return {"id": cur.lastrowid}


def _own_garage_row(ctx, ub_id):
    row = one(ctx.conn.execute(
        "SELECT ub.*, y.bike_id FROM user_bikes ub"
        " JOIN bike_years y ON y.id=ub.bike_year_id WHERE ub.id=?", (ub_id,)))
    if not row:
        raise HttpError(404, "not in your garage")
    if row["user_id"] != ctx.user["id"]:
        raise HttpError(403, "not your bike")
    return row


@route("PATCH", r"/api/garage/(\d+)", role="user")
def update_garage(ctx):
    ub = _own_garage_row(ctx, int(ctx.params[0]))
    ctx.conn.execute(
        "UPDATE user_bikes SET nickname=COALESCE(?,nickname),"
        " mileage=COALESCE(?,mileage) WHERE id=?",
        (ctx.body.get("nickname"), ctx.body.get("mileage"), ub["id"]))
    ctx.conn.commit()
    return {"ok": True}


@route("DELETE", r"/api/garage/(\d+)", role="user")
def remove_garage(ctx):
    ub = _own_garage_row(ctx, int(ctx.params[0]))
    ctx.conn.execute("DELETE FROM user_bikes WHERE id=?", (ub["id"],))
    ctx.conn.commit()
    return {"ok": True}


@route("GET", r"/api/garage/(\d+)/service", role="user")
def garage_service(ctx):
    ub = _own_garage_row(ctx, int(ctx.params[0]))
    tasks = rows(ctx.conn.execute(
        "SELECT * FROM service_tasks ORDER BY sort_order"))
    out = []
    for t in tasks:
        linked = rows(ctx.conn.execute(
            "SELECT f.label, s.value, s.confidence, s.tools"
            " FROM service_task_specs ts"
            " JOIN spec_fields f ON f.field_key = ts.field_key"
            " LEFT JOIN specs s ON s.field_key = ts.field_key AND s.bike_id = ?"
            " WHERE ts.task_key = ? ORDER BY ts.sort_order",
            (ub["bike_id"], t["task_key"])))
        # A task whose specs do not exist on this bike is not a task for this
        # bike — a shaft-drive machine has no chain to lube.
        if not any(l["value"] is not None for l in linked):
            continue
        history = rows(ctx.conn.execute(
            "SELECT id, performed_on, miles, note FROM service_log"
            " WHERE user_bike_id=? AND task_key=?"
            " ORDER BY performed_on DESC, id DESC",
            (ub["id"], t["task_key"])))
        interval = _interval_miles(ctx.conn, ub["bike_id"], t)
        status, due_in = "never", None
        if history:
            last = history[0]
            if interval and last["miles"] is not None and ub["mileage"] is not None:
                due_in = (last["miles"] + interval) - ub["mileage"]
                status = "overdue" if due_in < 0 else ("soon" if due_in < interval * 0.15 else "ok")
            else:
                status = "logged"
        out.append({**t, "specs": linked, "history": history,
                    "interval_miles": interval, "status": status,
                    "due_in_miles": due_in})
    return {"bike": ub, "tasks": out}


@route("POST", r"/api/garage/(\d+)/service", role="user")
def log_service(ctx):
    ub = _own_garage_row(ctx, int(ctx.params[0]))
    task_key = ctx.field("task_key")
    if not ctx.conn.execute("SELECT 1 FROM service_tasks WHERE task_key=?",
                            (task_key,)).fetchone():
        raise HttpError(404, "unknown task")
    performed_on = ctx.field("performed_on")
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", performed_on):
        raise HttpError(400, "performed_on must be YYYY-MM-DD")
    miles = ctx.body.get("miles")
    cur = ctx.conn.execute(
        "INSERT INTO service_log (user_bike_id, task_key, performed_on, miles, note)"
        " VALUES (?,?,?,?,?)",
        (ub["id"], task_key, performed_on, miles, ctx.body.get("note")))
    # Logging service at a higher odometer reading is the most reliable moment
    # to learn the bike's current mileage, so take it.
    if miles and (ub["mileage"] is None or miles > ub["mileage"]):
        ctx.conn.execute("UPDATE user_bikes SET mileage=? WHERE id=?", (miles, ub["id"]))
    ctx.conn.commit()
    return {"id": cur.lastrowid}


# ===========================================================================
# QUESTIONNAIRE
#
# Two distinct jobs, easy to confuse:
#   /definition + /build  — decide WHICH fields this bike has (the Spec Tree)
#   /<id> + /answer       — fill in the values for fields it already has
# ===========================================================================
@route("GET", r"/api/questionnaire/definition", role="manager")
def questionnaire_definition(ctx):
    doc = questionnaire.load()
    return {"questions": doc["questions"], "primary_order": doc["primary_order"],
            "bike_types": doc["bike_types"]}


@route("POST", r"/api/bikes", role="admin")
def create_bike(ctx):
    """Create a bike, then run the questionnaire against it to give it a tree.

    Admin only. A manager does not pick up bikes — an admin assigns them, so
    letting a manager create one would be self-assignment through the back door.
    """
    make = ctx.field("make")
    model_code = ctx.field("model_code")
    year_start = int(ctx.field("year_start"))
    year_end = int(ctx.body.get("year_end") or year_start)
    if year_end < year_start:
        raise HttpError(400, "year_end cannot be before year_start")

    try:
        cur = ctx.conn.execute(
            "INSERT INTO bikes (make, model_code, year_start, year_end,"
            " bike_type, years_verified) VALUES (?,?,?,?,?,1)",
            (make, model_code, year_start, year_end, ctx.body.get("bike_type")))
    except sqlite3.IntegrityError:
        raise HttpError(409, "a bike with that make, model and start year exists")
    bike_id = cur.lastrowid

    ctx.conn.execute(
        "INSERT INTO bike_names (bike_id, name, market, is_primary)"
        " VALUES (?,?,'',1)",
        (bike_id, ctx.body.get("name") or f"{make} {model_code}"))
    for y in range(year_start, year_end + 1):
        try:
            ctx.conn.execute(
                "INSERT INTO bike_years (bike_id, year, market) VALUES (?,?,'')",
                (bike_id, y))
        except sqlite3.IntegrityError as e:
            # The overlap trigger fired: another bike of this model already
            # owns that year. Roll the whole thing back rather than leave a
            # bike covering a partial range it did not ask for.
            ctx.conn.rollback()
            raise HttpError(409, f"model year {y} is already claimed by another bike")

    # Fields marked universal belong on every bike, including one created a
    # year after the field was. Applied here so a bike is never missing them
    # just because nobody re-ran a back-fill.
    universal = ctx.conn.execute(
        "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence)"
        " SELECT ?, field_key, NULL, 'pending' FROM spec_fields WHERE universal=1",
        (bike_id,)).rowcount

    # A new bike starts with no manager. Assigning one is a separate, deliberate
    # admin action — see /api/admin/bikes/<id>/manager.
    ctx.conn.commit()
    return {"bike_id": bike_id, "universal_fields": universal}


@route("POST", r"/api/questionnaire/(\d+)/build", role="manager")
def build_spec_tree(ctx):
    """Turn questionnaire answers into the bike's set of fields.

    The bike's manager, or an admin. Answering "does this bike have a battery?"
    is knowledge about one machine, which is exactly what the manager was
    assigned for — it is not a platform decision. What stays with admin is
    which fields EXIST at all: a branch proposal creates a field for every bike
    in the catalogue, and that is a different kind of authority from saying
    which existing questions apply to yours.

    The server re-walks the branching rather than trusting a field list from
    the client — otherwise the tree would be whatever the browser claimed.
    """
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)
    answers = ctx.body.get("answers")
    if not isinstance(answers, dict) or not answers:
        raise HttpError(400, "answers must be an object of question -> option")

    try:
        path, fields, not_sure, bike_type, answers = questionnaire.run(answers)
    except questionnaire.QuestionnaireError as e:
        raise HttpError(400, str(e))
    # From here on `answers` is only what the walk used. The submitted payload
    # can carry replies to questions this bike never reached — the wizard keeps
    # them so going back shows what you chose — and acting on those would put
    # specs on a bike for a branch it is not on.

    created = 0
    for label, _category in fields.items():
        key = re.sub(r"[^a-z0-9]+", "_",
                     label.lower().replace("×", " x ").replace("&", " and ")).strip("_")
        if not ctx.conn.execute("SELECT 1 FROM spec_fields WHERE field_key=?",
                                (key,)).fetchone():
            # Should be unreachable: the seeder registers every triggerable
            # field. If it happens, the questionnaire and the registry have
            # drifted, and silently inventing a field would hide that.
            raise HttpError(500, f"questionnaire triggered unregistered field {label!r}")
        cur = ctx.conn.execute(
            "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence)"
            " VALUES (?,?,NULL,'pending')", (bike_id, key))
        created += cur.rowcount

    # Universal fields, which no answer controls.
    cur = ctx.conn.execute(
        "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence)"
        " SELECT ?, field_key, NULL, 'pending' FROM spec_fields WHERE universal=1",
        (bike_id,))
    created += cur.rowcount
    universal_added = cur.rowcount

    # Fields attached to a branch after the fact, by an approved proposal.
    # questionnaire.json only knows the built-in tree; without this pass an
    # approved field would never reach a bike no matter how it answered.
    extra = 0
    for qid, opt in answers.items():
        for row in ctx.conn.execute(
                "SELECT field_key FROM field_triggers"
                " WHERE question_id=? AND option_label=?", (qid, opt)):
            cur = ctx.conn.execute(
                "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence)"
                " VALUES (?,?,NULL,'pending')", (bike_id, row[0]))
            created += cur.rowcount
            extra += cur.rowcount

    # Keep the answers. They are the only record of why this bike has these
    # fields, and a field attached to a branch later needs them to find the
    # bikes it should apply to. Re-running replaces rather than accumulates.
    ctx.conn.execute("DELETE FROM bike_answers WHERE bike_id=?", (bike_id,))
    ctx.conn.executemany(
        "INSERT INTO bike_answers (bike_id, question_id, option_label, answered_by)"
        " VALUES (?,?,?,?)",
        [(bike_id, qid, opt, ctx.user["id"]) for qid, opt in answers.items()])

    for item in not_sure:
        ctx.conn.execute(
            "INSERT INTO not_sure_answers (bike_id, question_text, submitted_by)"
            " VALUES (?,?,?)", (bike_id, item["text"], ctx.user["id"]))

    if bike_type:
        ctx.conn.execute("UPDATE bikes SET bike_type=? WHERE id=?",
                         (bike_type, bike_id))

    # Re-answering only ever ADDS. If a bike previously answered "has a battery"
    # and now says it does not, the battery fields stay — removing them would
    # destroy values somebody sourced, on a re-run that might have been a
    # mis-click. So report them instead: the manager can see what no longer
    # fits and have it removed deliberately.
    triggered = set()
    for label in fields:
        triggered.add(re.sub(r"[^a-z0-9]+", "_",
                             label.lower().replace("×", " x ").replace("&", " and ")
                             ).strip("_"))
    for qid, opt in answers.items():
        for row in ctx.conn.execute(
                "SELECT field_key FROM field_triggers"
                " WHERE question_id=? AND option_label=?", (qid, opt)):
            triggered.add(row[0])
    for row in ctx.conn.execute(
            "SELECT field_key FROM spec_fields WHERE universal=1"):
        triggered.add(row[0])

    stale = rows(ctx.conn.execute(
        "SELECT f.label, s.value FROM specs s"
        " JOIN spec_fields f ON f.field_key = s.field_key"
        " WHERE s.bike_id = ?", (bike_id,)))
    present = rows(ctx.conn.execute(
        "SELECT field_key FROM specs WHERE bike_id = ?", (bike_id,)))
    no_longer = [r["field_key"] for r in present if r["field_key"] not in triggered]
    no_longer_detail = rows(ctx.conn.execute(
        "SELECT f.label, s.value IS NOT NULL AND s.value <> '' AS has_value"
        " FROM specs s JOIN spec_fields f ON f.field_key = s.field_key"
        " WHERE s.bike_id = ? AND s.field_key IN (%s)"
        % (",".join("?" * len(no_longer)) or "''"),
        [bike_id] + no_longer)) if no_longer else []

    ctx.conn.commit()
    return {"questions_asked": len(path),
            "no_longer_applies": no_longer_detail,
            "fields_triggered": len(fields) + extra + universal_added,
            "from_approved_branches": extra,
            "universal_fields": universal_added,
            "specs_created": created, "not_sure": len(not_sure),
            "bike_type": bike_type}


@route("GET", r"/api/questionnaire/(\d+)", role="manager")
def questionnaire_gaps(ctx):
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)
    return {
        "bike": one(ctx.conn.execute(
            "SELECT * FROM bike_display WHERE bike_id=?", (bike_id,))),
        "questions": rows(ctx.conn.execute(
            "SELECT s.id AS spec_id, s.field_key, f.label, f.category,"
            " f.spec_type, s.value, s.confidence"
            " FROM specs s JOIN spec_fields f ON f.field_key=s.field_key"
            " WHERE s.bike_id=? AND (s.value IS NULL OR s.value='')"
            " ORDER BY f.sort_order, f.label", (bike_id,))),
        "answered": ctx.conn.execute(
            "SELECT COUNT(*) FROM specs WHERE bike_id=? AND value IS NOT NULL"
            " AND value <> ''", (bike_id,)).fetchone()[0],
        # What this bike answered last time, so re-running the questionnaire
        # starts from those answers instead of a blank form.
        "answers": {r["question_id"]: r["option_label"] for r in rows(ctx.conn.execute(
            "SELECT question_id, option_label FROM bike_answers WHERE bike_id=?",
            (bike_id,)))},
    }


@route("POST", r"/api/questionnaire/(\d+)/answer", role="manager")
def answer_question(ctx):
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)
    field_key = ctx.field("field_key")
    spec = one(ctx.conn.execute(
        "SELECT s.id, f.label FROM specs s JOIN spec_fields f ON f.field_key=s.field_key"
        " WHERE s.bike_id=? AND s.field_key=?", (bike_id, field_key)))
    if not spec:
        raise HttpError(404, "no such field on this bike")

    if ctx.body.get("not_sure"):
        # Not an answer — a question for admin. The spec stays NULL, which is
        # honest: still a gap, now with someone looking at it.
        cur = ctx.conn.execute(
            "INSERT INTO not_sure_answers (bike_id, field_key, question_text,"
            " submitted_by) VALUES (?,?,?,?)",
            (bike_id, field_key, spec["label"], ctx.user["id"]))
        ctx.conn.commit()
        return {"not_sure_id": cur.lastrowid}

    confidence = ctx.body.get("confidence") or "pending"
    if confidence not in ("confirmed", "mfr", "pending"):
        raise HttpError(400, "unknown confidence")
    ctx.conn.execute(
        "UPDATE specs SET value=?, confidence=?, entered_by=?,"
        " updated_at=datetime('now') WHERE id=?",
        (ctx.field("value"), confidence, ctx.user["id"], spec["id"]))
    ctx.conn.commit()
    return {"ok": True}


# ===========================================================================
# ADMIN
# ===========================================================================
@route("GET", r"/api/admin/summary", role="admin")
def admin_summary(ctx):
    c = ctx.conn
    q = lambda sql: c.execute(sql).fetchone()[0]
    return {
        "tree_flags":      q("SELECT COUNT(*) FROM tree_flags WHERE status='open'"),
        "proposals":       q("SELECT COUNT(*) FROM branch_proposals WHERE status='pending'"),
        "user_flags":      q("SELECT COUNT(*) FROM user_flags WHERE status='open'"),
        "not_sure":        q("SELECT COUNT(*) FROM not_sure_answers WHERE status='pending'"),
        "divergence":      q("SELECT COUNT(*) FROM divergence_queue"),
        "link_flags":      q("SELECT COUNT(*) FROM link_flags WHERE status='open'"),
        "unverified_years": q("SELECT COUNT(*) FROM bikes WHERE years_verified=0"),
        "manager_changes": q("SELECT COUNT(*) FROM manager_notices WHERE seen_at IS NULL"),
        "managers":        q("SELECT COUNT(DISTINCT user_id) FROM bike_managers"),
        "managed_bikes":   q("SELECT COUNT(DISTINCT bike_id) FROM bike_managers"),
        "catalog_dropped": q("SELECT COUNT(*) FROM catalog_v2_dropped"),
        "bikes":           q("SELECT COUNT(*) FROM bikes"),
        "specs":           q("SELECT COUNT(*) FROM specs"),
        "users":           q("SELECT COUNT(*) FROM users"),
    }


@route("GET", r"/api/admin/tree-flags", role="admin")
def admin_tree_flags(ctx):
    return {"items": rows(ctx.conn.execute(
        "SELECT t.id, t.question_text, t.comment, t.status, t.created_at,"
        " u.username AS flagged_by, d.display_name AS bike_name"
        " FROM tree_flags t LEFT JOIN users u ON u.id=t.flagged_by"
        " LEFT JOIN bike_display d ON d.bike_id=t.bike_id"
        " WHERE t.status='open' ORDER BY t.created_at DESC"))}


@route("POST", r"/api/admin/tree-flags/(\d+)/decide", role="admin")
def decide_tree_flag(ctx):
    status = ctx.field("status")
    if status not in ("accepted", "rejected"):
        raise HttpError(400, "status must be accepted or rejected")
    ctx.conn.execute(
        "UPDATE tree_flags SET status=?, admin_note=?, resolved_at=datetime('now')"
        " WHERE id=? AND status='open'",
        (status, ctx.body.get("admin_note"), int(ctx.params[0])))
    log_action(ctx, "treeflag.decide", f"{status.title()} tree flag #{ctx.params[0]}",
               target=ctx.params[0], detail={"status": status,
                                             "note": ctx.body.get("admin_note")})
    ctx.conn.commit()
    return {"ok": True}


@route("GET", r"/api/admin/proposals", role="admin")
def admin_proposals(ctx):
    return {"items": rows(ctx.conn.execute(
        # bike_id, not just bike_name: the console offers "add this field to the
        # proposing bike now", and that needs the id to send back.
        "SELECT p.id, p.field_name, p.category, p.reasoning, p.status,"
        " p.created_at, p.bike_id, u.username AS proposed_by,"
        " d.display_name AS bike_name"
        " FROM branch_proposals p LEFT JOIN users u ON u.id=p.proposed_by"
        " LEFT JOIN bike_display d ON d.bike_id=p.bike_id"
        " WHERE p.status='pending' ORDER BY p.created_at DESC"))}


def parse_triggers(ctx):
    """Read a branch list off the request.

    Accepts the list form `triggers: [{question, option}, ...]` and the older
    single `trigger_question`/`trigger_option` pair, so existing callers keep
    working while the dialog gains a second branch.

    Several branches on one field are a UNION, not a contradiction: a chain/belt
    tension spec legitimately belongs on q3=A and q3=B while staying off q3=C.
    build_spec_tree already ORs them.
    """
    raw = ctx.body.get("triggers")
    if raw is None:
        qid = ctx.body.get("trigger_question")
        opt = ctx.body.get("trigger_option")
        if not qid and not opt:
            return []
        if not (qid and opt):
            raise HttpError(400, "a branch needs both a question and an option")
        raw = [{"question": qid, "option": opt}]
    if not isinstance(raw, list):
        raise HttpError(400, "triggers must be a list")

    doc = questionnaire.load()
    out = []
    for t in raw:
        qid, opt = (t or {}).get("question"), (t or {}).get("option")
        if not (qid and opt):
            raise HttpError(400, "a branch needs both a question and an option")
        q = doc["questions"].get(qid)
        if not q:
            raise HttpError(400, "no such question: " + str(qid))
        if not any(o["l"] == opt for o in q["options"]):
            raise HttpError(400, repr(opt) + " is not an option for " + str(qid))
        if (qid, opt) not in out:
            out.append((qid, opt))
    return out


def bikes_matching(conn, triggers):
    """Distinct bikes answering ANY of these branches — the back-fill target."""
    if not triggers:
        return []
    clauses = " OR ".join(["(question_id=? AND option_label=?)"] * len(triggers))
    args = [v for pair in triggers for v in pair]
    return [r[0] for r in conn.execute(
        "SELECT DISTINCT bike_id FROM bike_answers WHERE " + clauses, args)]


@route("GET", r"/api/admin/unplaced-fields", role="admin")
def admin_unplaced_fields(ctx):
    """Fields that exist on the Spec Tree but appear on no bike.

    Approving a proposal creates the field; putting it somewhere is a separate
    decision, and it is easy to approve without making it — especially when the
    proposal named no bike and the chosen branch happens to match nothing. The
    result is a field nobody can see, with nothing to say so. This is that
    missing feedback.
    """
    # Fields the static questionnaire can trigger are NOT orphans — they are
    # waiting for a bike that answers that way (belt drive, 2-stroke, carbs 2-6).
    # Lumping them in buries the handful that genuinely reach nothing.
    tree_keys = {
        re.sub(r"[^a-z0-9]+", "_",
               label.lower().replace("×", " x ").replace("&", " and ")).strip("_")
        for label in questionnaire.all_triggerable_fields()
    }

    all_unplaced = rows(ctx.conn.execute(
        "SELECT f.field_key, f.label, f.category, f.spec_type, f.universal, f.created_at,"
        "       p.id AS proposal_id, u.username AS proposed_by,"
        "       (SELECT COUNT(*) FROM field_triggers t"
        "         WHERE t.field_key = f.field_key) AS triggers,"
        "       (SELECT GROUP_CONCAT(t.question_id || '=' || t.option_label, ', ')"
        "          FROM field_triggers t WHERE t.field_key = f.field_key) AS trigger_list"
        " FROM spec_fields f"
        " LEFT JOIN branch_proposals p ON p.created_field_key = f.field_key"
        " LEFT JOIN users u ON u.id = p.proposed_by"
        " WHERE NOT EXISTS (SELECT 1 FROM specs s WHERE s.field_key = f.field_key)"
        " ORDER BY f.created_at DESC"))

    orphans, waiting = [], []
    for f in all_unplaced:
        f["in_questionnaire"] = f["field_key"] in tree_keys
        (waiting if f["in_questionnaire"] else orphans).append(f)

    # orphans   — reach no bike and nothing will ever give them one
    # waiting   — a questionnaire branch will supply them when a bike matches
    return {"fields": orphans, "waiting": waiting,
            "waiting_count": len(waiting)}


# Mirrors seed.CATEGORY_ORDER. The browse page groups by consecutive runs of
# sort_order, so a category's fields have to stay contiguous: each category owns
# a 1000-wide band, and its index here is what picks the band.
CATEGORY_ORDER = ["General", "Engine", "Drive", "Fuel and Air",
                  "Controls", "Suspension", "Electrical"]
BAND = 1000


def next_sort_order(conn, category):
    """Where a field joining `category` should sit: last among its new siblings.

    Anchored to the category's band rather than to MAX+n alone, because MAX of
    an empty category is nothing — filing the first field of an empty category
    at 1 would drop it into General's band and split General in two on the
    browse page.

    If the band is full the category is compacted back to 10, 20, 30 first.
    That renumbers rows but changes no order, which is the whole point of
    numbering sparsely in the first place.
    """
    if category not in CATEGORY_ORDER:
        raise HttpError(400, f"unknown category: {category!r}")
    base = CATEGORY_ORDER.index(category) * BAND
    top = conn.execute(
        "SELECT MAX(sort_order) FROM spec_fields WHERE category=?",
        (category,)).fetchone()[0]
    if top is None:
        return base + 10
    if top + 10 < base + BAND:
        return top + 10

    siblings = [r[0] for r in conn.execute(
        "SELECT field_key FROM spec_fields WHERE category=?"
        " ORDER BY sort_order, label", (category,))]
    for i, key in enumerate(siblings):
        conn.execute("UPDATE spec_fields SET sort_order=? WHERE field_key=?",
                     (base + (i + 1) * 10, key))
    return base + (len(siblings) + 1) * 10


def log_action(ctx, action, summary, target=None, detail=None, destructive=False):
    """Record an admin action.

    Written on the same connection as the change itself, so it commits or rolls
    back with it — an audit row for something that did not happen would be
    worse than no row at all.

    `detail` carries what a summary cannot: on a deletion, the values that were
    destroyed. That does not make it undoable, but it is the difference between
    "we can find out what was lost" and "it is gone".
    """
    ctx.conn.execute(
        "INSERT INTO admin_actions (user_id, action, target, summary, detail,"
        " destructive) VALUES (?,?,?,?,?,?)",
        (ctx.user["id"], action, str(target) if target is not None else None,
         summary, json.dumps(detail) if detail is not None else None,
         1 if destructive else 0))


@route("GET", r"/api/admin/activity", role="admin")
def admin_activity(ctx):
    """What has been done, most recent first.

    Defaults to the signed-in admin's own actions, since "changes I have made"
    is the usual question; `?who=all` widens it once there is more than one
    admin.
    """
    who = ctx.arg("who", "me")
    limit = min(int(ctx.arg("limit", "60")), 300)
    where, args = "", []
    if who != "all":
        where = " WHERE a.user_id = ?"
        args = [ctx.user["id"]]
    if ctx.arg("destructive") == "1":
        where = (where + " AND" if where else " WHERE") + " a.destructive = 1"

    return {"actions": rows(ctx.conn.execute(
        "SELECT a.id, a.action, a.target, a.summary, a.detail, a.destructive,"
        "       a.created_at, u.username"
        " FROM admin_actions a LEFT JOIN users u ON u.id = a.user_id"
        f"{where} ORDER BY a.created_at DESC, a.id DESC LIMIT ?", args + [limit])),
        "total": ctx.conn.execute(
            f"SELECT COUNT(*) FROM admin_actions a{where}", args).fetchone()[0],
        "destructive_total": ctx.conn.execute(
            "SELECT COUNT(*) FROM admin_actions WHERE destructive = 1").fetchone()[0]}


@route("GET", r"/api/spec-tree", role="manager")
def spec_tree(ctx):
    """The whole tree: every field, what puts it on a bike, how far it is filled.

    Manager and above. Not because the field names are secret — a rider sees
    them on any spec sheet — but because this is the shape of the platform's
    data model, including the fields that reach nobody, and it is a working
    view for the people who maintain it rather than a page for readers.

    One query for the fields and one for the triggers, joined in Python: a
    group_concat over field_triggers would otherwise multiply the spec counts
    for any field sitting on two branches.
    """
    fields = rows(ctx.conn.execute(
        "SELECT f.field_key, f.label, f.category, f.spec_type, f.universal,"
        "       f.sort_order,"
        "       (SELECT COUNT(*) FROM specs s WHERE s.field_key=f.field_key)"
        "         AS bikes,"
        "       (SELECT COUNT(*) FROM specs s WHERE s.field_key=f.field_key"
        "          AND s.value IS NOT NULL AND TRIM(s.value)<>'') AS filled,"
        # How many of those rows no rider can see. A field staged offline reads
        # as "on 262 bikes" without this, which is true and misleading.
        "       (SELECT COUNT(*) FROM specs s WHERE s.field_key=f.field_key"
        "          AND s.paused=1) AS offline"
        " FROM spec_fields f ORDER BY f.sort_order, f.label"))

    triggers = {}
    for t in rows(ctx.conn.execute(
            "SELECT field_key, question_id, option_label FROM field_triggers"
            " ORDER BY field_key, question_id, option_label")):
        triggers.setdefault(t["field_key"], []).append(t)

    # The option's own wording, so the page can say "Belt drive" rather than
    # making the reader decode q3=B.
    defn = questionnaire.load()["questions"]
    for f in fields:
        out = []
        for t in triggers.get(f["field_key"], []):
            q = defn.get(t["question_id"], {})
            text = next((o["t"] for o in q.get("options", [])
                         if o["l"] == t["option_label"]), t["option_label"])
            out.append({"question_id": t["question_id"],
                        "option": t["option_label"], "text": text,
                        "question": q.get("text", "")})
        f["triggers"] = out

    return {
        "fields": fields,
        "categories": [c[0] for c in ctx.conn.execute(
            "SELECT category FROM spec_fields"
            " GROUP BY category ORDER BY MIN(sort_order)")],
        "bikes_total": ctx.conn.execute(
            "SELECT COUNT(*) FROM bikes").fetchone()[0],
    }


@route("GET", r"/api/admin/fields", role="admin")
def admin_list_fields(ctx):
    """Every field on the Spec Tree, with what removing it would cost.

    values_set is the number that carry a value somebody sourced. Deleting a
    field cascades its spec rows away, taking those values, their alternates and
    their votes with them — so the count has to be on screen before the button
    is, not in a dialog after.
    """
    q = ctx.arg("q", "").strip()
    where, args = "", []
    if q:
        where = " WHERE f.label LIKE ? OR f.category LIKE ?"
        args = [f"%{q}%", f"%{q}%"]
    limit = min(int(ctx.arg("limit", "40")), 200)

    fields = rows(ctx.conn.execute(
        "SELECT f.field_key, f.label, f.category, f.spec_type, f.universal,"
        "       f.sort_order,"
        # Where it sits in its category, so the ends can hide their arrow.
        "       (SELECT COUNT(*) FROM spec_fields x WHERE x.category=f.category"
        "          AND x.sort_order < f.sort_order) AS position,"
        "       (SELECT COUNT(*) FROM spec_fields x WHERE x.category=f.category) AS siblings,"
        "       (SELECT COUNT(*) FROM specs s WHERE s.field_key=f.field_key) AS bikes,"
        "       (SELECT COUNT(*) FROM specs s WHERE s.field_key=f.field_key"
        "          AND s.value IS NOT NULL AND s.value<>'') AS values_set,"
        "       (SELECT COUNT(*) FROM field_triggers t WHERE t.field_key=f.field_key) AS triggers,"
        "       (SELECT GROUP_CONCAT(t.question_id || '=' || t.option_label, ', ')"
        "          FROM field_triggers t WHERE t.field_key=f.field_key) AS trigger_list"
        f" FROM spec_fields f{where}"
        # By sort_order, not label: the rows carry "3 of 40" and up/down arrows,
        # and listing them alphabetically would show position 3 above position 1.
        " ORDER BY f.sort_order LIMIT ?", args + [limit]))

    # "q3=A" is precise and unreadable. Resolve every branch to the question
    # as asked and the answer as offered — and carry the other options too, so
    # the console can show the whole question rather than one line of it.
    defn = questionnaire.load()["questions"]
    trig = {}
    for t in rows(ctx.conn.execute(
            "SELECT field_key, question_id, option_label FROM field_triggers"
            " ORDER BY field_key, question_id, option_label")):
        q = defn.get(t["question_id"], {})
        opts = q.get("options", [])
        trig.setdefault(t["field_key"], []).append({
            "question_id": t["question_id"],
            "option": t["option_label"],
            "question": q.get("text", ""),
            "section": q.get("section", ""),
            "answer": next((o["t"] for o in opts if o["l"] == t["option_label"]),
                           t["option_label"]),
            "options": [{"l": o["l"], "t": o["t"]} for o in opts],
        })
    site, hidden = {}, set()
    for r in rows(ctx.conn.execute(
            "SELECT field_key, category, shown FROM spec_field_categories")):
        if r["shown"]:
            site.setdefault(r["field_key"], []).append(r["category"])
        else:
            hidden.add(r["field_key"])
    for f in fields:
        f["trigger_details"] = trig.get(f["field_key"], [])
        f["also_in"] = sorted(site.get(f["field_key"], []),
                              key=lambda c: CATEGORY_ORDER.index(c) if c in CATEGORY_ORDER else 99)
        f["home_shown"] = f["field_key"] not in hidden

    return {"fields": fields,
            "total": ctx.conn.execute(
                f"SELECT COUNT(*) FROM spec_fields f{where}", args).fetchone()[0]}


@route("POST", r"/api/admin/fields", role="admin")
def admin_create_field(ctx):
    """Add a spec to the tree directly.

    Until now the only way to create a field was to approve a branch proposal,
    which meant an admin who wanted one had to file it as a manager first and
    then approve their own request. The proposal flow exists so a manager can
    ASK; it should not be the only door for the person who decides.

    Placement is part of creation, not an afterthought. A field with no branch,
    no universal flag and no named bike exists on the tree and reaches nobody —
    that is what the "Fields on no bike" panel is full of — so this refuses to
    create one unless it is told where it goes.
    """
    label = ctx.field("label")
    if len(label) > 120:
        raise HttpError(400, "field name is limited to 120 characters")

    key = re.sub(r"[^a-z0-9]+", "_",
                 label.lower().replace("×", " x ").replace("&", " and ")).strip("_")
    if not key:
        raise HttpError(400, "field name must contain letters or numbers")
    if ctx.conn.execute("SELECT 1 FROM spec_fields WHERE field_key=?",
                        (key,)).fetchone():
        raise HttpError(409, f"a field named {label!r} already exists")

    category = ctx.field("category")
    if category not in CATEGORY_ORDER:
        raise HttpError(400, "category must be one of: " + ", ".join(CATEGORY_ORDER))

    spec_type = ctx.body.get("spec_type", "pref")
    if spec_type not in ("fixed", "pref", "community"):
        raise HttpError(400, "spec_type must be fixed, pref or community")

    triggers = parse_triggers(ctx)
    universal = bool(ctx.body.get("universal"))
    bike_ids = ctx.body.get("bike_ids") or []
    # Staged: the field is on the tree and attached to its bikes, but no rider
    # sees it until it is switched on. For a spec being written up, or one whose
    # branch you want to check before it lands on 262 spec sheets.
    offline = bool(ctx.body.get("offline"))

    if universal and triggers:
        raise HttpError(409, "a field cannot be on every bike and restricted to"
                             " a branch at the same time — universal wins"
                             " silently, which is how a 2-stroke oil spec ended"
                             " up on four-strokes")
    if not (universal or triggers or bike_ids):
        raise HttpError(400, "say where it goes: a branch, every bike, or"
                             " named bikes. A field with none of those reaches"
                             " nobody.")

    order = next_sort_order(ctx.conn, category)
    ctx.conn.execute(
        "INSERT INTO spec_fields (field_key, label, category, spec_type,"
        " sort_order, universal) VALUES (?,?,?,?,?,?)",
        (key, label, category, spec_type, order, 1 if universal else 0))

    for qid, opt in triggers:
        ctx.conn.execute(
            "INSERT OR IGNORE INTO field_triggers"
            " (field_key, question_id, option_label, created_by)"
            " VALUES (?,?,?,?)", (key, qid, opt, ctx.user["id"]))

    # paused_by/at are set on the same INSERT rather than a second UPDATE, so a
    # staged row is never briefly visible between the two.
    pz, pb = (1, ctx.user["id"]) if offline else (0, None)
    pa = "datetime('now')" if offline else "NULL"

    added = 0
    if universal:
        cur = ctx.conn.execute(
            "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence,"
            f" paused, paused_by, paused_at)"
            f" SELECT id, ?, NULL, 'pending', ?, ?, {pa} FROM bikes", (key, pz, pb))
        added += cur.rowcount
    if triggers and ctx.body.get("backfill"):
        for bike in bikes_matching(ctx.conn, triggers):
            cur = ctx.conn.execute(
                "INSERT OR IGNORE INTO specs (bike_id, field_key, value,"
                " confidence, paused, paused_by, paused_at)"
                f" VALUES (?,?,NULL,'pending',?,?,{pa})", (bike, key, pz, pb))
            added += cur.rowcount
    for bike in bike_ids:
        if not ctx.conn.execute("SELECT 1 FROM bikes WHERE id=?", (bike,)).fetchone():
            raise HttpError(404, f"no bike with id {bike}")
        cur = ctx.conn.execute(
            "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence,"
            " paused, paused_by, paused_at)"
            f" VALUES (?,?,NULL,'pending',?,?,{pa})", (bike, key, pz, pb))
        added += cur.rowcount

    where = ("every bike" if universal else
             ", ".join(f"{q}={o}" for q, o in triggers) if triggers else
             f"{len(bike_ids)} named bike(s)")
    log_action(ctx, "field.create",
               f'Added "{label}" to {category} on {where}'
               f" ({added} spec row(s)"
               + (", offline" if offline else "") + ")",
               target=key,
               detail={"label": label, "category": category,
                       "spec_type": spec_type, "universal": universal,
                       "offline": offline,
                       "triggers": [{"question": q, "option": o} for q, o in triggers],
                       "bike_ids": bike_ids, "rows_added": added})
    ctx.conn.commit()
    return {"ok": True, "field_key": key, "label": label, "category": category,
            "universal": universal, "rows_added": added, "offline": offline,
            "triggers": [{"question": q, "option": o} for q, o in triggers]}


@route("GET", r"/api/admin/fields/([a-z0-9_]+)/usage", role="admin")
def admin_field_usage(ctx):
    """Which bikes carry this field, and which of them have a value."""
    field_key = ctx.params[0]
    if not ctx.conn.execute("SELECT 1 FROM spec_fields WHERE field_key=?",
                            (field_key,)).fetchone():
        raise HttpError(404, "no such field")
    return {"bikes": rows(ctx.conn.execute(
        "SELECT s.id AS spec_id, s.bike_id, d.display_name, d.year_range,"
        "       s.value, s.confidence,"
        "       (SELECT COUNT(*) FROM spec_alternates a WHERE a.spec_id=s.id) AS alternates"
        " FROM specs s JOIN bike_display d ON d.bike_id = s.bike_id"
        " WHERE s.field_key = ?"
        " ORDER BY (s.value IS NULL OR s.value=''), d.display_name LIMIT 200",
        (field_key,)))}


@route("DELETE", r"/api/admin/bikes/(\d+)/specs/([a-z0-9_]+)", role="admin")
def admin_remove_spec_from_bike(ctx):
    """Take one field off one bike.

    Refuses while the spec still holds a value unless told explicitly: removing
    it deletes that value and any alternates and votes hanging off it, and
    "this field does not belong on this bike" is a different statement from
    "throw away what people recorded".
    """
    bike_id, field_key = int(ctx.params[0]), ctx.params[1]
    spec = one(ctx.conn.execute(
        "SELECT id, value FROM specs WHERE bike_id=? AND field_key=?",
        (bike_id, field_key)))
    if not spec:
        raise HttpError(404, "that bike does not have this field")

    has_value = spec["value"] not in (None, "")
    alternates = ctx.conn.execute(
        "SELECT COUNT(*) FROM spec_alternates WHERE spec_id=?", (spec["id"],)).fetchone()[0]
    if (has_value or alternates) and not ctx.body.get("force"):
        raise HttpError(409, "this spec holds a value or alternates — "
                             "removing it destroys them; confirm to proceed")

    meta = one(ctx.conn.execute(
        "SELECT d.display_name, f.label FROM bike_display d, spec_fields f"
        " WHERE d.bike_id = ? AND f.field_key = ?", (bike_id, field_key)))
    ctx.conn.execute("DELETE FROM specs WHERE id=?", (spec["id"],))
    log_action(ctx, "spec.remove",
               f'Removed "{meta["label"]}" from {meta["display_name"]}'
               + (f' — destroyed the value "{spec["value"]}"' if has_value else ""),
               target=field_key, destructive=bool(has_value or alternates),
               detail={"bike_id": bike_id, "bike": meta["display_name"],
                       "label": meta["label"], "value": spec["value"],
                       "alternates_destroyed": alternates})
    ctx.conn.commit()
    return {"ok": True, "value_destroyed": has_value, "alternates_destroyed": alternates}


@route("PATCH", r"/api/admin/fields/([a-z0-9_]+)/type", role="admin")
def admin_set_field_type(ctx):
    """Change a field's type across the whole tree.

    Distinct from PATCH /api/specs/<id>/type, which is a bike manager marking
    one spec on their own bike. This one is the platform-wide default for the
    field, which is admin's to decide — the same split as everywhere else:
    admin owns the tree, the manager owns their bike.

    'fixed' refuses alternates everywhere the field appears, so turning it on
    reports how many bikes carry it and how many alternates already exist that
    would be contradicted.
    """
    field_key = ctx.params[0]
    field = one(ctx.conn.execute(
        "SELECT field_key, label, spec_type FROM spec_fields WHERE field_key=?",
        (field_key,)))
    if not field:
        raise HttpError(404, "no such field")

    spec_type = ctx.field("spec_type")
    if spec_type not in ("fixed", "pref", "community"):
        raise HttpError(400, "spec_type must be fixed, pref or community")

    # Existing alternates are not deleted — they are somebody's contribution,
    # and marking the field fixed is a statement about future ones. But the
    # admin should know they are there.
    orphaned = ctx.conn.execute(
        "SELECT COUNT(*) FROM spec_alternates a JOIN specs s ON s.id = a.spec_id"
        " WHERE s.field_key = ?", (field_key,)).fetchone()[0]

    ctx.conn.execute("UPDATE spec_fields SET spec_type=? WHERE field_key=?",
                     (spec_type, field_key))
    log_action(ctx, "field.type",
               f'"{field["label"]}" is now {spec_type}'
               + (f" (was {field['spec_type']})" if field["spec_type"] != spec_type else ""),
               target=field_key,
               detail={"from": field["spec_type"], "to": spec_type,
                       "existing_alternates": orphaned})
    ctx.conn.commit()
    return {"ok": True, "spec_type": spec_type, "was": field["spec_type"],
            "existing_alternates": orphaned}


@route("PATCH", r"/api/admin/fields/([a-z0-9_]+)/label", role="admin")
def rename_field(ctx):
    """Change what a field is called on every spec sheet.

    Only the label moves. field_key stays as it was, because it is what specs,
    field_triggers and bike_header_specs all point at, and it is what the
    Guides links carry — the schema separates the two precisely so a rename is
    one UPDATE rather than a sweep across three tables and every saved URL. The
    stale key is invisible to readers; "Curb Weight" was renamed to "Dry Weight"
    this way and its rows still say curb_weight.

    Admin-only: the label is what all 261 bikes show, so this is a Spec Tree
    decision, not something scoped to one manager's bikes.
    """
    field_key = ctx.params[0]
    field = one(ctx.conn.execute(
        "SELECT field_key, label, category FROM spec_fields WHERE field_key=?",
        (field_key,)))
    if not field:
        raise HttpError(404, "no such field")

    label = ctx.field("label")
    if len(label) > 120:
        raise HttpError(400, "label must be 120 characters or fewer")
    if label == field["label"]:
        raise HttpError(409, f"\"{label}\" is already its name")

    # Two fields reading the same on a spec sheet is indistinguishable to the
    # reader, whatever their keys say.
    clash = one(ctx.conn.execute(
        "SELECT field_key, category FROM spec_fields"
        " WHERE LOWER(TRIM(label))=LOWER(TRIM(?)) AND field_key<>?",
        (label, field_key)))
    if clash:
        raise HttpError(409, f"\"{label}\" is already the name of another "
                             f"field, in {clash['category']}")

    ctx.conn.execute("UPDATE spec_fields SET label=? WHERE field_key=?",
                     (label, field_key))
    bikes = ctx.conn.execute("SELECT COUNT(*) FROM specs WHERE field_key=?",
                             (field_key,)).fetchone()[0]
    log_action(ctx, "field.rename",
               f"Renamed \"{field['label']}\" to \"{label}\" "
               f"({bikes} bike{'' if bikes == 1 else 's'} affected)",
               target=field_key,
               detail={"was": field["label"], "now": label,
                       "field_key": field_key, "bikes": bikes})
    ctx.conn.commit()
    return {"ok": True, "field_key": field_key, "label": label,
            "was": field["label"], "bikes": bikes}


@route("PATCH", r"/api/admin/fields/([a-z0-9_]+)/category", role="admin")
def set_field_category(ctx):
    """Re-file a field under a different category.

    Admin-only, and deliberately not something a manager can reach: category
    sits on the field, so moving one moves it on every bike at once. A manager
    is scoped to their own bikes, and this is the opposite of scoped.

    The spec rows are untouched — they reference the field, not the category —
    so no value is at risk. What changes is where the field appears on every
    spec sheet, and its sort_order, which has to be re-derived because the old
    number belongs to the old category's band.

    The field lands last in its new category; ▲▼ moves it from there.
    """
    field_key = ctx.params[0]
    field = one(ctx.conn.execute(
        "SELECT field_key, label, category, sort_order FROM spec_fields"
        " WHERE field_key=?", (field_key,)))
    if not field:
        raise HttpError(404, "no such field")

    category = ctx.field("category")
    if category not in CATEGORY_ORDER:
        raise HttpError(400, "category must be one of: "
                             + ", ".join(CATEGORY_ORDER))
    if category == field["category"]:
        raise HttpError(409, f"\"{field['label']}\" is already in {category}")

    order = next_sort_order(ctx.conn, category)
    ctx.conn.execute(
        "UPDATE spec_fields SET category=?, sort_order=? WHERE field_key=?",
        (category, order, field_key))

    bikes = ctx.conn.execute("SELECT COUNT(*) FROM specs WHERE field_key=?",
                             (field_key,)).fetchone()[0]
    log_action(ctx, "field.category",
               f"Moved \"{field['label']}\" from {field['category']} to "
               f"{category} ({bikes} bike{'' if bikes == 1 else 's'} affected)",
               target=field_key,
               detail={"from": field["category"], "to": category,
                       "was_sort_order": field["sort_order"],
                       "now_sort_order": order, "bikes": bikes})
    ctx.conn.commit()
    return {"ok": True, "field_key": field_key, "category": category,
            "sort_order": order, "bikes": bikes}


@route("POST", r"/api/admin/fields/([a-z0-9_]+)/visibility", role="admin")
def set_field_visibility(ctx):
    """Take a whole field online or offline in one go, on every bike carrying it.

    The per-bike control a manager uses is one spec on one machine. This is the
    other end of it: a field staged offline across 262 bikes needs one switch to
    publish, not 262 visits. Admin-only for the same reason the field itself is
    — it lands on every bike at once.

    Only rows already carrying the field are touched. A bike that answers the
    branch later gets a normal, visible row: "offline" describes the rows that
    exist, not a permanent property of the field.
    """
    field_key = ctx.params[0]
    field = one(ctx.conn.execute(
        "SELECT field_key, label FROM spec_fields WHERE field_key=?", (field_key,)))
    if not field:
        raise HttpError(404, "no such field")

    want = ctx.body.get("online")
    if want is None:
        raise HttpError(400, "online is required (true or false)")
    paused = 0 if want else 1

    cur = ctx.conn.execute(
        "UPDATE specs SET paused=?, paused_by=?,"
        "  paused_at = CASE WHEN ?=1 THEN datetime('now') ELSE NULL END,"
        "  updated_at = datetime('now')"
        " WHERE field_key=? AND paused<>?",
        (paused, ctx.user["id"] if paused else None, paused, field_key, paused))
    changed = cur.rowcount

    total = ctx.conn.execute("SELECT COUNT(*) FROM specs WHERE field_key=?",
                             (field_key,)).fetchone()[0]
    log_action(ctx, "field.visibility",
               f'Took "{field["label"]}" {"online" if want else "offline"}'
               f" on {changed} of {total} bike(s)",
               target=field_key,
               detail={"online": bool(want), "changed": changed, "total": total})
    ctx.conn.commit()
    return {"ok": True, "field_key": field_key, "label": field["label"],
            "online": bool(want), "changed": changed, "total": total}


@route("POST", r"/api/admin/fields/([a-z0-9_]+)/move", role="admin")
def admin_move_field(ctx):
    """Move a field up or down within its category.

    Swaps sort_order with its neighbour rather than recomputing the category:
    two UPDATEs, and every other field keeps the number it had, so nothing else
    shifts underneath a second admin working at the same time.

    Movement is confined to the category. Sort order also decides which
    category band a field sits in, and the browse page builds its category
    headings from consecutive runs — a field crossing a band would appear under
    somebody else's heading. Moving between categories is a different operation.
    """
    field_key = ctx.params[0]
    field = one(ctx.conn.execute(
        "SELECT field_key, label, category, sort_order FROM spec_fields"
        " WHERE field_key=?", (field_key,)))
    if not field:
        raise HttpError(404, "no such field")

    direction = ctx.field("direction")
    if direction not in ("up", "down"):
        raise HttpError(400, "direction must be up or down")

    op, order = ("<", "DESC") if direction == "up" else (">", "ASC")
    neighbour = one(ctx.conn.execute(
        f"SELECT field_key, label, sort_order FROM spec_fields"
        f" WHERE category=? AND sort_order {op} ?"
        f" ORDER BY sort_order {order} LIMIT 1",
        (field["category"], field["sort_order"])))
    if not neighbour:
        raise HttpError(409, f"\"{field['label']}\" is already "
                             f"{'first' if direction == 'up' else 'last'} in "
                             f"{field['category']}")

    ctx.conn.execute("UPDATE spec_fields SET sort_order=? WHERE field_key=?",
                     (neighbour["sort_order"], field["field_key"]))
    ctx.conn.execute("UPDATE spec_fields SET sort_order=? WHERE field_key=?",
                     (field["sort_order"], neighbour["field_key"]))
    log_action(ctx, "field.move",
               f"Moved \"{field['label']}\" {direction} in {field['category']}, "
               f"past \"{neighbour['label']}\"",
               target=field_key,
               detail={"direction": direction, "category": field["category"],
                       "swapped_with": neighbour["field_key"]})
    ctx.conn.commit()
    return {"ok": True, "moved": direction, "swapped_with": neighbour["label"],
            "sort_order": neighbour["sort_order"]}


@route("POST", r"/api/admin/fields/([a-z0-9_]+)/universal", role="admin")
def admin_set_field_universal(ctx):
    """Mark a field as belonging on every bike — or stop it doing so.

    Turning it on does not by itself touch existing bikes; back-filling is a
    separate tick, because it writes one spec row per bike and the admin should
    know that before it happens. Turning it off leaves already-created rows
    alone: they may hold values somebody entered, and silently deleting those
    would be the one destructive thing in this whole flow.
    """
    field_key = ctx.params[0]
    if not ctx.conn.execute("SELECT 1 FROM spec_fields WHERE field_key=?",
                            (field_key,)).fetchone():
        raise HttpError(404, "no such field")
    universal = ctx.body.get("universal")
    if not isinstance(universal, bool):
        raise HttpError(400, "universal must be true or false")

    # "Every bike" and "only bikes answering q5=A" are contradictory statements
    # about the same field, and universal silently won — which is how a 2-stroke
    # oil spec ended up on 260 four-strokes. One of the two is wrong and only
    # the admin knows which, so refuse rather than quietly pick one.
    if universal:
        branches = rows(ctx.conn.execute(
            "SELECT question_id, option_label FROM field_triggers WHERE field_key=?",
            (field_key,)))
        if branches:
            listed = ", ".join(b["question_id"] + "=" + b["option_label"]
                               for b in branches)
            raise HttpError(409,
                            "this field is restricted to " + listed +
                            ", which contradicts 'every bike'. Remove the branch "
                            "first if it really belongs on every machine.")

    ctx.conn.execute("UPDATE spec_fields SET universal=? WHERE field_key=?",
                     (1 if universal else 0, field_key))
    added = 0
    if universal and ctx.body.get("backfill"):
        cur = ctx.conn.execute(
            "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence)"
            " SELECT b.id, ?, NULL, 'pending' FROM bikes b", (field_key,))
        added = cur.rowcount
    label = ctx.conn.execute("SELECT label FROM spec_fields WHERE field_key=?",
                             (field_key,)).fetchone()[0]
    log_action(ctx, "field.universal",
               (f'"{label}" now applies to every bike'
                + (f" — added to {added}" if added else "")) if universal
               else f'"{label}" no longer applies to every bike (existing bikes keep it)',
               target=field_key, detail={"universal": universal, "added": added})
    ctx.conn.commit()
    return {"ok": True, "universal": universal, "added": added,
            "bikes": ctx.conn.execute("SELECT COUNT(*) FROM bikes").fetchone()[0]}


@route("POST", r"/api/admin/fields/([a-z0-9_]+)/trigger", role="admin")
def admin_set_field_trigger(ctx):
    """Change which questionnaire branch a field belongs to.

    Approval was the only place a branch could be chosen, so picking the wrong
    option — belt conditioner attached to Driveshaft rather than Belt drive —
    left no way to correct it. Replaces rather than adds: a field belonging to
    two contradictory answers to the same question is a mistake, not a feature.
    """
    field_key = ctx.params[0]
    if not ctx.conn.execute("SELECT 1 FROM spec_fields WHERE field_key=?",
                            (field_key,)).fetchone():
        raise HttpError(404, "no such field")

    triggers = parse_triggers(ctx)
    if not triggers:
        raise HttpError(400, "give at least one branch, or DELETE to clear them")

    # Replaces the whole set, so the dialog's list is exactly what ends up
    # stored — removing a branch there actually removes it.
    ctx.conn.execute("DELETE FROM field_triggers WHERE field_key=?", (field_key,))
    for qid, opt in triggers:
        ctx.conn.execute(
            "INSERT INTO field_triggers (field_key, question_id, option_label, created_by)"
            " VALUES (?,?,?,?)", (field_key, qid, opt, ctx.user["id"]))

    matched = bikes_matching(ctx.conn, triggers)
    backfilled = 0
    if ctx.body.get("backfill"):
        for bike in matched:
            cur = ctx.conn.execute(
                "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence)"
                " VALUES (?,?,NULL,'pending')", (bike, field_key))
            backfilled += cur.rowcount
    ctx.conn.commit()

    doc = questionnaire.load()
    labels = [next(o["t"] for o in doc["questions"][q]["options"] if o["l"] == lab)
              for q, lab in triggers]
    label = ctx.conn.execute("SELECT label FROM spec_fields WHERE field_key=?",
                             (field_key,)).fetchone()[0]
    log_action(ctx, "field.branches",
               f'Set "{label}" to apply on: {", ".join(labels)}',
               target=field_key,
               detail={"triggers": [{"question": q, "option": o} for q, o in triggers],
                       "matching_bikes": len(matched), "backfilled": backfilled})
    ctx.conn.commit()
    return {"ok": True,
            "triggers": [{"question": q, "option": lab} for q, lab in triggers],
            "option_text": ", ".join(labels),
            "matching_bikes": len(matched), "backfilled": backfilled}


@route("DELETE", r"/api/admin/fields/([a-z0-9_]+)/trigger", role="admin")
def admin_clear_field_trigger(ctx):
    cur = ctx.conn.execute("DELETE FROM field_triggers WHERE field_key=?",
                           (ctx.params[0],))
    if cur.rowcount:
        log_action(ctx, "field.branches.clear",
                   f"Detached {ctx.params[0]} from {cur.rowcount} branch(es)"
                   " — bikes that already have it keep it",
                   target=ctx.params[0], detail={"removed": cur.rowcount})
    ctx.conn.commit()
    return {"ok": True, "removed": cur.rowcount}


@route("POST", r"/api/admin/fields/([a-z0-9_]+)/apply", role="admin")
def admin_apply_field(ctx):
    """Put a field onto named bikes. The 'or just pick specific bike' route —
    and the only one that reaches catalog bikes, which answered no
    questionnaire and so match no branch."""
    field_key = ctx.params[0]
    if not ctx.conn.execute("SELECT 1 FROM spec_fields WHERE field_key=?",
                            (field_key,)).fetchone():
        raise HttpError(404, "no such field")
    bike_ids = ctx.body.get("bike_ids")
    if not isinstance(bike_ids, list) or not bike_ids:
        raise HttpError(400, "bike_ids must be a non-empty list")

    added, missing = 0, []
    for bid in bike_ids:
        if not ctx.conn.execute("SELECT 1 FROM bikes WHERE id=?", (bid,)).fetchone():
            missing.append(bid)
            continue
        cur = ctx.conn.execute(
            "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence)"
            " VALUES (?,?,NULL,'pending')", (bid, field_key))
        added += cur.rowcount
    if missing:
        ctx.conn.rollback()
        raise HttpError(404, f"no such bike: {missing}")
    label = ctx.conn.execute("SELECT label FROM spec_fields WHERE field_key=?",
                             (field_key,)).fetchone()[0]
    log_action(ctx, "field.apply",
               f'Added "{label}" to {added} bike(s)',
               target=field_key, detail={"bike_ids": bike_ids, "added": added})
    ctx.conn.commit()
    return {"ok": True, "added": added}


@route("DELETE", r"/api/admin/fields/([a-z0-9_]+)", role="admin")
def admin_delete_field(ctx):
    """Remove a field that should not have been created.

    Refused once any bike carries it — deleting then would cascade away real
    spec rows, and possibly values people had entered. Detach it from the bikes
    first, deliberately.
    """
    field_key = ctx.params[0]
    if not ctx.conn.execute("SELECT 1 FROM spec_fields WHERE field_key=?",
                            (field_key,)).fetchone():
        raise HttpError(404, "no such field")

    # A field the questionnaire still asks for cannot simply go: the walk would
    # trigger a label with no field behind it, and every bike answering that
    # way would fail. This is not a "are you sure" — force does not override it,
    # because the fix is to edit the questionnaire, not to accept a broken one.
    label = ctx.conn.execute("SELECT label FROM spec_fields WHERE field_key=?",
                             (field_key,)).fetchone()[0]
    asked_by = questionnaire.questions_triggering(label)
    if asked_by:
        where = ", ".join(
            f"{h['question_id']}={h['option']}" if h["option"] else h["question_id"]
            for h in asked_by)
        raise HttpError(409,
                        f"the questionnaire still asks for {label!r} at {where}"
                        f" — remove it there first, or answering that way will"
                        f" fail for every bike")

    used = ctx.conn.execute("SELECT COUNT(*) FROM specs WHERE field_key=?",
                            (field_key,)).fetchone()[0]
    with_values = ctx.conn.execute(
        "SELECT COUNT(*) FROM specs WHERE field_key=? AND value IS NOT NULL"
        " AND value <> ''", (field_key,)).fetchone()[0]

    # Refuse by default when in use. Deleting cascades the spec rows, and with
    # them any values, alternates and votes — the counts go back so the console
    # can say exactly what is about to be lost rather than "are you sure?".
    if used and not ctx.body.get("force"):
        raise HttpError(409, f"{used} bike(s) already use this field"
                             f"{f', {with_values} with a value' if with_values else ''}"
                             f" — confirm to delete it and them")

    # Capture what is about to be destroyed, before it is. A summary saying
    # "63 values lost" is useless for recovery; the values themselves are not.
    lost = rows(ctx.conn.execute(
        "SELECT s.bike_id, d.display_name, s.value, s.confidence"
        " FROM specs s JOIN bike_display d ON d.bike_id = s.bike_id"
        " WHERE s.field_key = ? AND s.value IS NOT NULL AND s.value <> ''",
        (field_key,)))
    label = ctx.conn.execute("SELECT label FROM spec_fields WHERE field_key=?",
                             (field_key,)).fetchone()[0]

    ctx.conn.execute("DELETE FROM field_triggers WHERE field_key=?", (field_key,))
    ctx.conn.execute("DELETE FROM spec_fields WHERE field_key=?", (field_key,))
    log_action(ctx, "field.delete",
               f'Deleted the field "{label}"'
               + (f" from {used} bike(s), destroying {with_values} value(s)" if used else ""),
               target=field_key, destructive=bool(used),
               detail={"label": label, "bikes_affected": used,
                       "values_destroyed": with_values, "lost_values": lost})
    ctx.conn.commit()
    return {"ok": True, "bikes_affected": used, "values_destroyed": with_values}


@route("GET", r"/api/admin/branches", role="admin")
def admin_branches(ctx):
    """The questionnaire branches an approved field can be attached to, each
    with how many existing bikes answered that way.

    The count is the blast radius: attaching a field to "Q3 = chain drive" and
    back-filling changes every one of those bikes' spec sheets, and an admin
    should see that number before committing to it.
    """
    doc = questionnaire.load()
    counts = {}
    for r in ctx.conn.execute(
            "SELECT question_id, option_label, COUNT(*) AS n"
            " FROM bike_answers GROUP BY question_id, option_label"):
        counts[f"{r['question_id']}|{r['option_label']}"] = r["n"]

    out = []
    for qid in doc["primary_order"] + [q for q in doc["questions"]
                                       if q not in doc["primary_order"]]:
        q = doc["questions"].get(qid)
        if not q:
            continue
        out.append({
            "question_id": qid,
            "section": q["section"],
            "text": q["text"],
            "options": [{"label": o["l"], "text": o["t"],
                         "bikes": counts.get(f"{qid}|{o['l']}", 0)}
                        for o in q["options"]],
        })
    return {"branches": out,
            "bikes_with_answers": ctx.conn.execute(
                "SELECT COUNT(DISTINCT bike_id) FROM bike_answers").fetchone()[0],
            "bikes_total": ctx.conn.execute(
                "SELECT COUNT(*) FROM bikes").fetchone()[0]}


@route("POST", r"/api/admin/proposals/(\d+)/decide", role="admin")
def decide_proposal(ctx):
    """Approving creates the field for real — that is what makes this an admin
    decision. An approved field becomes available to every bike, not just the
    proposer's, so the tree grows here and nowhere else."""
    pid = int(ctx.params[0])
    status = ctx.field("status")
    if status not in ("approved", "rejected"):
        raise HttpError(400, "status must be approved or rejected")
    p = one(ctx.conn.execute(
        "SELECT * FROM branch_proposals WHERE id=? AND status='pending'", (pid,)))
    if not p:
        raise HttpError(404, "no pending proposal with that id")

    created_key = None
    backfilled = 0
    applied_to_bike = False
    if status == "approved":
        # The admin can reword the field before it is created. A proposer types
        # "belt conditioner"; what goes on the tree is read by every rider on
        # every bike, so the wording is worth settling here rather than living
        # with whatever was typed in a hurry. The proposal keeps its original
        # text either way, so the change stays visible.
        label = (ctx.body.get("field_name") or p["field_name"]).strip()
        if not label:
            raise HttpError(400, "field name cannot be empty")
        if len(label) > 120:
            raise HttpError(400, "field name is limited to 120 characters")

        created_key = re.sub(r"[^a-z0-9]+", "_",
                             label.lower().replace("×", " x ").replace("&", " and ")
                             ).strip("_")
        if not created_key:
            raise HttpError(400, "field name must contain letters or numbers")
        if ctx.conn.execute("SELECT 1 FROM spec_fields WHERE field_key=?",
                            (created_key,)).fetchone():
            raise HttpError(409, f"a field named {label!r} already exists")
        # Admin can re-file it on the way in, for the same reason they can
        # reword the name: the proposer picked from a dropdown without seeing
        # how the rest of the tree is organised.
        category = ctx.body.get("category") or p["category"]
        if category not in CATEGORY_ORDER:
            raise HttpError(400, "category must be one of: "
                                 + ", ".join(CATEGORY_ORDER))
        order = next_sort_order(ctx.conn, category)
        ctx.conn.execute(
            "INSERT INTO spec_fields (field_key, label, category, spec_type,"
            " sort_order, from_proposal_id) VALUES (?,?,?,?,?,?)",
            (created_key, label, category,
             ctx.body.get("spec_type", "pref"), order, pid))

        # Where the field actually lives. Creating the row is not enough: a
        # field with no branch and no bike appears in no tree and does nothing.
        triggers = parse_triggers(ctx)
        for qid, opt in triggers:
            ctx.conn.execute(
                "INSERT OR IGNORE INTO field_triggers"
                " (field_key, question_id, option_label, created_by)"
                " VALUES (?,?,?,?)", (created_key, qid, opt, ctx.user["id"]))

        # Back-filling is the admin's call, which is why the console shows the
        # count first — it rewrites the spec sheet of every matching bike.
        if triggers and ctx.body.get("backfill"):
            for bike in bikes_matching(ctx.conn, triggers):
                cur = ctx.conn.execute(
                    "INSERT OR IGNORE INTO specs"
                    " (bike_id, field_key, value, confidence)"
                    " VALUES (?,?,NULL,'pending')", (bike, created_key))
                backfilled += cur.rowcount

        # Straight onto one named bike — for a one-off, or for a catalog bike
        # that never answered the questionnaire and so no branch can reach.
        if ctx.body.get("apply_to_bike") and p["bike_id"]:
            cur = ctx.conn.execute(
                "INSERT OR IGNORE INTO specs (bike_id, field_key, value, confidence)"
                " VALUES (?,?,NULL,'pending')", (p["bike_id"], created_key))
            applied_to_bike = bool(cur.rowcount)

    ctx.conn.execute(
        "UPDATE branch_proposals SET status=?, admin_note=?, created_field_key=?,"
        " resolved_at=datetime('now') WHERE id=?",
        (status, ctx.body.get("admin_note"), created_key, pid))

    if status == "approved":
        log_action(ctx, "proposal.approve",
                   f'Approved "{p["field_name"]}"'
                   + (f' as "{label}"' if label != p["field_name"] else "")
                   + f" into {category}"
                   + (f" (proposed for {p['category']})"
                      if category != p["category"] else ""),
                   target=created_key,
                   detail={"proposal_id": pid, "proposed_as": p["field_name"],
                           "created_as": label, "category": category,
                           "proposed_category": p["category"],
                           "triggers": [{"question": q, "option": o} for q, o in triggers],
                           "backfilled": backfilled,
                           "applied_to_proposing_bike": applied_to_bike})
    else:
        log_action(ctx, "proposal.reject", f'Rejected "{p["field_name"]}"',
                   target=str(pid), detail={"proposal_id": pid,
                                            "note": ctx.body.get("admin_note")})
    ctx.conn.commit()
    return {"ok": True, "created_field_key": created_key,
            "created_label": label if status == "approved" else None,
            "renamed": status == "approved" and label != p["field_name"],
            "backfilled": backfilled, "applied_to_bike": applied_to_bike}


@route("GET", r"/api/admin/user-flags", role="admin")
def admin_user_flags(ctx):
    return {"items": rows(ctx.conn.execute(
        "SELECT uf.id, uf.reason, uf.detail, uf.status, uf.created_at,"
        " t.username AS flagged_user, t.id AS flagged_user_id, t.suspended,"
        " b.username AS flagged_by"
        " FROM user_flags uf JOIN users t ON t.id=uf.flagged_user"
        " JOIN users b ON b.id=uf.flagged_by"
        " WHERE uf.status='open' ORDER BY uf.created_at DESC"))}


@route("POST", r"/api/admin/user-flags/(\d+)/decide", role="admin")
def decide_user_flag(ctx):
    status = ctx.field("status")
    if status not in ("actioned", "dismissed"):
        raise HttpError(400, "status must be actioned or dismissed")
    uf = one(ctx.conn.execute("SELECT * FROM user_flags WHERE id=?",
                              (int(ctx.params[0]),)))
    if not uf:
        raise HttpError(404, "flag not found")
    if status == "actioned" and ctx.body.get("suspend"):
        ctx.conn.execute("UPDATE users SET suspended=1 WHERE id=?", (uf["flagged_user"],))
        # Suspension has to end the sessions too, or the account keeps working
        # until the cookie happens to expire.
        ctx.conn.execute("DELETE FROM sessions WHERE user_id=?", (uf["flagged_user"],))
    ctx.conn.execute(
        "UPDATE user_flags SET status=?, admin_note=?, resolved_at=datetime('now')"
        " WHERE id=?", (status, ctx.body.get("admin_note"), uf["id"]))
    target_name = ctx.conn.execute("SELECT username FROM users WHERE id=?",
                                   (uf["flagged_user"],)).fetchone()[0]
    suspended = status == "actioned" and bool(ctx.body.get("suspend"))
    log_action(ctx, "userflag.decide",
               f"{status.title()} the flag on {target_name}"
               + (" — account suspended and sessions ended" if suspended else ""),
               target=target_name, destructive=suspended,
               detail={"flag_id": uf["id"], "status": status,
                       "suspended": suspended, "reason": uf["reason"]})
    ctx.conn.commit()
    return {"ok": True}


@route("GET", r"/api/admin/not-sure", role="admin")
def admin_not_sure(ctx):
    return {"items": rows(ctx.conn.execute(
        "SELECT n.id, n.question_text, n.field_key, n.status, n.created_at,"
        " u.username AS submitted_by, d.display_name AS bike_name, n.bike_id"
        " FROM not_sure_answers n LEFT JOIN users u ON u.id=n.submitted_by"
        " JOIN bike_display d ON d.bike_id=n.bike_id"
        " WHERE n.status='pending' ORDER BY n.created_at DESC"))}


@route("POST", r"/api/admin/not-sure/(\d+)/decide", role="admin")
def decide_not_sure(ctx):
    """Admin confirming an answer writes it to the spec, which is the whole
    point of the queue — otherwise the question is closed and the gap remains."""
    nid = int(ctx.params[0])
    status = ctx.field("status")
    if status not in ("confirmed", "rejected"):
        raise HttpError(400, "status must be confirmed or rejected")
    n = one(ctx.conn.execute(
        "SELECT * FROM not_sure_answers WHERE id=? AND status='pending'", (nid,)))
    if not n:
        raise HttpError(404, "no pending item with that id")
    value = ctx.body.get("value")
    if status == "confirmed":
        if not value:
            raise HttpError(400, "confirming needs a value")
        if not n["field_key"]:
            raise HttpError(400, "this question is not tied to a field, so there "
                                 "is nothing to write a value to")
        ctx.conn.execute(
            "UPDATE specs SET value=?, confidence='confirmed', entered_by=?,"
            " updated_at=datetime('now') WHERE bike_id=? AND field_key=?",
            (value, ctx.user["id"], n["bike_id"], n["field_key"]))
    ctx.conn.execute(
        "UPDATE not_sure_answers SET status=?, admin_note=?,"
        " resolved_at=datetime('now') WHERE id=?",
        (status, ctx.body.get("admin_note"), nid))
    log_action(ctx, "notsure.decide",
               (f'Confirmed "{n["question_text"]}" as "{value}"' if status == "confirmed"
                else f'Closed "{n["question_text"]}" without an answer'),
               target=n["field_key"],
               detail={"id": nid, "status": status, "value": value,
                       "bike_id": n["bike_id"]})
    ctx.conn.commit()
    return {"ok": True}


@route("GET", r"/api/admin/divergence", role="admin")
def admin_divergence(ctx):
    return {"items": rows(ctx.conn.execute(
        "SELECT q.*, f.label,"
        " da.display_name AS bike_a_name, db.display_name AS bike_b_name,"
        " da.year_range AS bike_a_years, db.year_range AS bike_b_years"
        " FROM divergence_queue q"
        " JOIN spec_fields f ON f.field_key = q.field_key"
        " JOIN bike_display da ON da.bike_id = q.bike_a"
        " JOIN bike_display db ON db.bike_id = q.bike_b"
        " ORDER BY q.lineage_root, f.label LIMIT 200"))}


@route("POST", r"/api/admin/divergence/ack", role="admin")
def ack_divergence(ctx):
    ctx.conn.execute(
        "INSERT OR IGNORE INTO divergence_ack (bike_a, bike_b, field_key,"
        " value_a, value_b, reviewed_by, note) VALUES (?,?,?,?,?,?,?)",
        (ctx.field("bike_a"), ctx.field("bike_b"), ctx.field("field_key"),
         ctx.body.get("value_a"), ctx.body.get("value_b"),
         ctx.user["id"], ctx.body.get("note")))
    log_action(ctx, "divergence.ack",
               f'Marked {ctx.field("field_key")} reviewed between bikes '
               f'{ctx.field("bike_a")} and {ctx.field("bike_b")}',
               target=ctx.field("field_key"),
               detail={"bike_a": ctx.field("bike_a"), "bike_b": ctx.field("bike_b"),
                       "value_a": ctx.body.get("value_a"),
                       "value_b": ctx.body.get("value_b")})
    ctx.conn.commit()
    return {"ok": True}


@route("GET", r"/api/admin/catalog-dropped", role="admin")
def admin_catalog_dropped(ctx):
    limit = min(int(ctx.arg("limit", "100")), 1000)
    return {"items": rows(ctx.conn.execute(
        "SELECT * FROM catalog_v2_dropped LIMIT ?", (limit,))),
        "total": ctx.conn.execute(
            "SELECT COUNT(*) FROM catalog_v2_dropped").fetchone()[0]}


@route("GET", r"/api/admin/unverified-years", role="admin")
def admin_unverified(ctx):
    return {"items": rows(ctx.conn.execute(
        "SELECT d.bike_id, d.display_name, d.year_range,"
        " (SELECT COUNT(*) FROM bike_years y WHERE y.bike_id=d.bike_id) AS year_count"
        " FROM bike_display d WHERE d.years_verified=0"
        " ORDER BY d.display_name LIMIT 200"))}


# ---------------------------------------------------------------------------
# A bike's identity: its name, and splitting it at a model year.
#
# Both are open to the bike's manager as well as admin. The manager knows the
# machine; making them ask admin to fix "Honda CB919" to "Honda CB900F 919"
# is the kind of gate that stops the fix happening. But both change what every
# rider sees at the top of the page, so when a manager does one the admin is
# told -- a notice after the fact, not a permission.
#
# The rule for when to split, from the owner: split when it is a different
# machine -- different engine, different frame. Year-scope a single spec when
# it is the same machine with a different part. The page says the same.
# ---------------------------------------------------------------------------
def notify_admin(ctx, kind, bike_id, summary, detail=None):
    """A manager changed their own bike. Admin did it themselves -> no notice;
    the audit row is enough."""
    if ctx.user["role"] == "admin":
        return
    ctx.conn.execute(
        "INSERT INTO manager_notices (bike_id, actor, kind, summary, detail)"
        " VALUES (?,?,?,?,?)",
        (bike_id, ctx.user["id"], kind, summary,
         json.dumps(detail) if detail is not None else None))


def _bike_names(conn, bike_id):
    return rows(conn.execute(
        "SELECT name, market, is_primary FROM bike_names WHERE bike_id=?"
        " ORDER BY is_primary DESC, name", (bike_id,)))


@route("PATCH", r"/api/bikes/(\d+)/name", role="manager")
def rename_bike(ctx):
    """Change the name riders see, and the other names the bike is sold under.

    make and model_code are not touched: they are the internal identity the
    catalog keys on and the make+model+year uniqueness rule hangs on. The
    display name is the reader-facing name and moves freely, the same way a
    spec field's label renames while its key stays put.
    """
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)
    bike = one(ctx.conn.execute(
        "SELECT display_name, year_range FROM bike_display WHERE bike_id=?", (bike_id,)))
    if not bike:
        raise HttpError(404, "bike not found")

    name = ctx.field("name")
    if len(name) > 80:
        raise HttpError(400, "name is too long (80 characters at most)")

    others = ctx.body.get("other_names")
    if others is not None:
        if not isinstance(others, list):
            raise HttpError(400, "other_names must be a list")
        clean = []
        for o in others:
            if not isinstance(o, dict):
                raise HttpError(400, "each other name is {name, market}")
            n = str(o.get("name") or "").strip()
            m = str(o.get("market") or "").strip().upper()
            if not n:
                continue
            if len(n) > 80 or len(m) > 10:
                raise HttpError(400, "an other name or its market is too long")
            clean.append((n, m))
        others = clean

    was = {"display_name": bike["display_name"], "names": _bike_names(ctx.conn, bike_id)}

    # The primary row keeps its market (CB919's is US). A non-primary row that
    # already carries the new name in that market would collide with the
    # UNIQUE (bike_id, name, market); it is the same fact, so it goes.
    primary = one(ctx.conn.execute(
        "SELECT id, market FROM bike_names WHERE bike_id=? AND is_primary=1", (bike_id,)))
    if primary:
        ctx.conn.execute(
            "DELETE FROM bike_names WHERE bike_id=? AND is_primary=0 AND name=? AND market=?",
            (bike_id, name, primary["market"]))
        ctx.conn.execute("UPDATE bike_names SET name=? WHERE id=?", (name, primary["id"]))
        pmarket = primary["market"]
    else:
        ctx.conn.execute(
            "DELETE FROM bike_names WHERE bike_id=? AND name=? AND market=''", (bike_id, name))
        ctx.conn.execute(
            "INSERT INTO bike_names (bike_id, name, market, is_primary) VALUES (?,?,'',1)",
            (bike_id, name))
        pmarket = ""

    if others is not None:
        ctx.conn.execute("DELETE FROM bike_names WHERE bike_id=? AND is_primary=0", (bike_id,))
        for n, m in others:
            if n == name and m == pmarket:
                continue
            ctx.conn.execute(
                "INSERT OR IGNORE INTO bike_names (bike_id, name, market, is_primary)"
                " VALUES (?,?,?,0)", (bike_id, n, m))

    now = _bike_names(ctx.conn, bike_id)
    detail = {"was": was, "now": {"display_name": name, "names": now}}
    changed = was["display_name"] != name
    summary = (f'Renamed "{was["display_name"]}" to "{name}"' if changed
               else f'Updated the other names of "{name}"')
    log_action(ctx, "bike.rename", summary, target=bike_id, detail=detail)
    notify_admin(ctx, "rename", bike_id,
                 f'{ctx.user["username"]} {summary[0].lower() + summary[1:]}'
                 + (f' ({bike["year_range"]})' if bike["year_range"] else ""), detail)
    ctx.conn.commit()
    return {"ok": True, "bike_id": bike_id, "display_name": name, "names": now,
            "notified_admin": ctx.user["role"] != "admin"}


@route("POST", r"/api/bikes/(\d+)/split", role="manager")
def split_bike(ctx):
    """Split a bike at a model year: the years from `at_year` on become a new
    bike with a copy of the spec set.

    What moves and what copies:
      * model years from `at_year` on MOVE to the new bike, row ids intact, so
        a rider's garage entry for an '85 follows the '85.
      * a spec that is year-scoped entirely inside the later span MOVES with
        its alternates, votes and flags; one that straddles the split is cut
        at the year, the earlier part staying and the later part copied.
      * every other spec is COPIED, with its alternates -- the two bikes start
        from one identical sheet, which is what sibling_divergence watches.
        Votes and open flags are not copied: a vote is a rider's opinion about
        one bike, and a flag is a conversation about one row.
      * tools, links, header pins, questionnaire answers and managers are
        copied. The manager who split it keeps both halves.
    """
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)
    bike = one(ctx.conn.execute("SELECT * FROM bikes WHERE id=?", (bike_id,)))
    if not bike:
        raise HttpError(404, "bike not found")
    try:
        at = int(ctx.field("at_year"))
    except (TypeError, ValueError):
        raise HttpError(400, "at_year must be a year")

    start = bike["year_start"]
    end = bike["year_end"]
    if end is None:  # still current: the last model year on record stands in
        end = ctx.conn.execute("SELECT MAX(year) FROM bike_years WHERE bike_id=?",
                               (bike_id,)).fetchone()[0]
    if start is None or end is None:
        raise HttpError(400, "this bike has no year span to split")
    if not (start < at <= end):
        raise HttpError(400, f"pick a year after {start} and no later than {end}")

    if ctx.conn.execute(
            "SELECT 1 FROM bikes WHERE make=? AND model_code=? AND year_start=?",
            (bike["make"], bike["model_code"], at)).fetchone():
        raise HttpError(409, f"a {bike['make']} {bike['model_code']} already starts at {at}")

    name = one(ctx.conn.execute("SELECT display_name FROM bike_display WHERE bike_id=?",
                                (bike_id,)))["display_name"]
    later_name = (ctx.body.get("name") or "").strip() or None
    if later_name and len(later_name) > 80:
        raise HttpError(400, "name is too long (80 characters at most)")

    c = ctx.conn
    cur = c.execute(
        "INSERT INTO bikes (make, model_code, year_start, year_end, bike_type,"
        " years_verified, split_from_bike_id, split_at_year) VALUES (?,?,?,?,?,1,?,?)",
        (bike["make"], bike["model_code"], at, bike["year_end"], bike["bike_type"],
         bike_id, at))
    new_id = cur.lastrowid
    c.execute("UPDATE bikes SET year_end=?, years_verified=1 WHERE id=?", (at - 1, bike_id))

    moved_years = c.execute(
        "UPDATE bike_years SET bike_id=? WHERE bike_id=? AND year>=?",
        (new_id, bike_id, at)).rowcount

    c.execute("INSERT INTO bike_names (bike_id, name, market, is_primary)"
              " SELECT ?, name, market, is_primary FROM bike_names WHERE bike_id=?",
              (new_id, bike_id))
    if later_name:
        c.execute("DELETE FROM bike_names WHERE bike_id=? AND is_primary=0 AND name=?"
                  " AND market=(SELECT market FROM bike_names WHERE bike_id=? AND is_primary=1)",
                  (new_id, later_name, new_id))
        c.execute("UPDATE bike_names SET name=? WHERE bike_id=? AND is_primary=1",
                  (later_name, new_id))
    c.execute("INSERT INTO bike_managers (user_id, bike_id, specialty)"
              " SELECT user_id, ?, specialty FROM bike_managers WHERE bike_id=?",
              (new_id, bike_id))
    c.execute("INSERT INTO bike_answers (bike_id, question_id, option_label, answered_by, answered_at)"
              " SELECT ?, question_id, option_label, answered_by, answered_at"
              " FROM bike_answers WHERE bike_id=?", (new_id, bike_id))
    c.execute("INSERT INTO spec_tools (bike_id, field_key, text, added_by, paused, created_at)"
              " SELECT ?, field_key, text, added_by, paused, created_at"
              " FROM spec_tools WHERE bike_id=?", (new_id, bike_id))
    c.execute("INSERT INTO spec_links (bike_id, field_key, link_type, title, url, added_by,"
              " paused, created_at) SELECT ?, field_key, link_type, title, url, added_by,"
              " paused, created_at FROM spec_links WHERE bike_id=?", (new_id, bike_id))
    c.execute("INSERT INTO bike_spec_categories (bike_id, field_key, category, shown, placed_by, placed_at)"
              " SELECT ?, field_key, category, shown, placed_by, placed_at"
              " FROM bike_spec_categories WHERE bike_id=?", (new_id, bike_id))
    c.execute("INSERT INTO bike_header_specs (bike_id, field_key, sort_order, hide_below,"
              " hidden, pinned_by, pinned_at) SELECT ?, field_key, sort_order, hide_below,"
              " hidden, pinned_by, pinned_at FROM bike_header_specs WHERE bike_id=?",
              (new_id, bike_id))

    def copy_spec(s, year_from, year_to):
        cur = c.execute(
            "INSERT INTO specs (bike_id, field_key, value, confidence, spec_type, tools,"
            " paused, paused_by, paused_at, entered_by, year_from, year_to)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (new_id, s["field_key"], s["value"], s["confidence"], s["spec_type"],
             s["tools"], s["paused"], s["paused_by"], s["paused_at"], s["entered_by"],
             year_from, year_to))
        c.execute(
            "INSERT INTO spec_alternates (spec_id, text, submitted_by, confirmed_fit, paused)"
            " SELECT ?, text, submitted_by, confirmed_fit, paused FROM spec_alternates"
            " WHERE spec_id=?", (cur.lastrowid, s["id"]))

    copied = moved = cut = 0
    for s in rows(c.execute("SELECT * FROM specs WHERE bike_id=? ORDER BY field_key, year_from",
                            (bike_id,))):
        if s["year_from"] is None:
            copy_spec(s, None, None)
            copied += 1
            continue
        lo = s["year_from"]
        hi = s["year_to"] if s["year_to"] is not None else end
        if hi < at:
            continue                                   # earlier years: stays put
        if lo >= at:                                   # later years: moves whole
            c.execute("UPDATE specs SET bike_id=? WHERE id=?", (new_id, s["id"]))
            moved += 1
            continue
        c.execute("UPDATE specs SET year_to=?, updated_at=datetime('now') WHERE id=?",
                  (at - 1, s["id"]))                   # straddles: cut at the year
        copy_spec(s, at, s["year_to"])
        cut += 1

    # A variant left covering its bike's whole span is no longer a variant.
    # "1975-1977" on every spec of a 1975-1977 bike is noise; clearing the
    # range says the same thing the way every other spec does.
    for b_id, b_start, b_end in ((bike_id, start, at - 1), (new_id, at, bike["year_end"])):
        c.execute(
            "UPDATE specs SET year_from=NULL, year_to=NULL WHERE bike_id=?"
            " AND year_from IS NOT NULL AND year_from=?"
            " AND ((? IS NULL AND year_to IS NULL) OR year_to=?)"
            " AND field_key IN (SELECT field_key FROM specs WHERE bike_id=?"
            "                   GROUP BY field_key HAVING COUNT(*)=1)",
            (b_id, b_start, b_end, b_end, b_id))

    earlier = one(c.execute("SELECT bike_id, display_name, year_range FROM bike_display"
                            " WHERE bike_id=?", (bike_id,)))
    later = one(c.execute("SELECT bike_id, display_name, year_range FROM bike_display"
                          " WHERE bike_id=?", (new_id,)))
    detail = {"at_year": at, "earlier": earlier, "later": later,
              "model_years_moved": moved_years, "specs_copied": copied,
              "specs_moved": moved, "specs_cut": cut}
    summary = (f'Split "{name}" at {at}: {earlier["year_range"]} and'
               f' {later["year_range"]}')
    log_action(ctx, "bike.split", summary, target=bike_id, detail=detail)
    notify_admin(ctx, "split", bike_id, f'{ctx.user["username"]} s{summary[1:]}', detail)
    c.commit()
    return {"ok": True, "earlier": earlier, "later": later,
            "model_years_moved": moved_years, "specs_copied": copied,
            "specs_moved": moved, "specs_cut": cut,
            "notified_admin": ctx.user["role"] != "admin"}


# ---------------------------------------------------------------------------
# The bike's photo.
#
# Uploaded by the bike's manager or an admin, as the raw image in the request
# body -- no multipart parsing to get wrong. The type is read from the bytes,
# not the header or the filename: a browser will happily call anything
# image/png, and an SVG is a script with a picture in it. Stored under
# data/photos as <bike_id>.<ext>, served at /photos/<file>.
# ---------------------------------------------------------------------------
PHOTO_DIR = os.path.join(ROOT, "data", "photos")
PHOTO_MAX_BYTES = 5 * 1024 * 1024
PHOTO_TYPES = {"image/jpeg": "jpg", "image/png": "png", "image/webp": "webp"}


def sniff_image(data):
    """The real type of the bytes, or None for anything not a JPEG, PNG or WebP."""
    if data[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


def photo_of(conn, bike_id):
    p = one(conn.execute(
        "SELECT p.file, p.mime, p.bytes, p.uploaded_at, u.username AS uploaded_by"
        " FROM bike_photos p LEFT JOIN users u ON u.id=p.uploaded_by WHERE p.bike_id=?",
        (bike_id,)))
    if not p:
        return None
    # the timestamp in the URL makes a replaced photo show at once instead of
    # the browser's cached copy of the old one
    p["url"] = f"/photos/{p['file']}?v={quote(p['uploaded_at'])}"
    return p


@route("POST", r"/api/bikes/(\d+)/photo", role="manager")
def upload_bike_photo(ctx):
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)
    bike = one(ctx.conn.execute("SELECT display_name, year_range FROM bike_display"
                                " WHERE bike_id=?", (bike_id,)))
    if not bike:
        raise HttpError(404, "bike not found")
    data = ctx.body.get("_raw") if isinstance(ctx.body, dict) else None
    if not data:
        raise HttpError(400, "send the image itself as the request body,"
                             " with its Content-Type")
    mime = sniff_image(data)
    if not mime:
        raise HttpError(400, "that is not a JPEG, PNG or WebP image")
    if len(data) > PHOTO_MAX_BYTES:
        raise HttpError(413, f"the photo is over {PHOTO_MAX_BYTES // (1024 * 1024)} MB")

    os.makedirs(PHOTO_DIR, exist_ok=True)
    fname = f"{bike_id}.{PHOTO_TYPES[mime]}"
    with open(os.path.join(PHOTO_DIR, fname), "wb") as f:
        f.write(data)
    old = one(ctx.conn.execute("SELECT file FROM bike_photos WHERE bike_id=?", (bike_id,)))
    if old and old["file"] != fname:              # a PNG replacing a JPEG
        try:
            os.remove(os.path.join(PHOTO_DIR, old["file"]))
        except OSError:
            pass
    ctx.conn.execute(
        "INSERT INTO bike_photos (bike_id, file, mime, bytes, uploaded_by, uploaded_at)"
        " VALUES (?,?,?,?,?,datetime('now'))"
        " ON CONFLICT(bike_id) DO UPDATE SET file=excluded.file, mime=excluded.mime,"
        " bytes=excluded.bytes, uploaded_by=excluded.uploaded_by,"
        " uploaded_at=excluded.uploaded_at",
        (bike_id, fname, mime, len(data), ctx.user["id"]))
    photo = photo_of(ctx.conn, bike_id)
    verb = "Replaced the photo of" if old else "Added a photo to"
    summary = f'{verb} "{bike["display_name"]}"'
    detail = {"file": fname, "mime": mime, "bytes": len(data), "url": photo["url"],
              "replaced": bool(old)}
    log_action(ctx, "bike.photo", summary, target=bike_id, detail=detail)
    notify_admin(ctx, "photo", bike_id,
                 f'{ctx.user["username"]} {summary[0].lower() + summary[1:]}'
                 + (f' ({bike["year_range"]})' if bike["year_range"] else ""), detail)
    ctx.conn.commit()
    return {"ok": True, "photo": photo, "notified_admin": ctx.user["role"] != "admin"}


@route("DELETE", r"/api/bikes/(\d+)/photo", role="manager")
def delete_bike_photo(ctx):
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)
    old = one(ctx.conn.execute("SELECT file FROM bike_photos WHERE bike_id=?", (bike_id,)))
    if not old:
        raise HttpError(404, "this bike has no photo")
    ctx.conn.execute("DELETE FROM bike_photos WHERE bike_id=?", (bike_id,))
    try:
        os.remove(os.path.join(PHOTO_DIR, old["file"]))
    except OSError:
        pass
    name = one(ctx.conn.execute("SELECT display_name FROM bike_display WHERE bike_id=?",
                                (bike_id,)))["display_name"]
    log_action(ctx, "bike.photo_remove", f'Removed the photo of "{name}"',
               target=bike_id, detail={"file": old["file"]}, destructive=True)
    ctx.conn.commit()
    return {"ok": True}


# ---------------------------------------------------------------------------
# A spec under more than one heading, on one bike.
#
# The field's home category is a Spec Tree fact and admin's to change. This is
# the per-bike addition: "on this bike, also show it under Electrical". The
# page prints a pointer there, so the value, its votes and its flags stay in
# one place and cannot drift.
# ---------------------------------------------------------------------------
@route("POST", r"/api/bikes/(\d+)/categories", role="manager")
def set_spec_categories(ctx):
    bike_id = int(ctx.params[0])
    require_manages(ctx.conn, ctx.user, bike_id)
    field_key = ctx.field("field_key")
    field = one(ctx.conn.execute(
        "SELECT f.label, f.category FROM spec_fields f"
        " WHERE f.field_key=? AND EXISTS (SELECT 1 FROM specs s"
        "   WHERE s.bike_id=? AND s.field_key=f.field_key)", (field_key, bike_id)))
    if not field:
        raise HttpError(404, "this bike has no such spec")
    cats = ctx.body.get("categories")
    if not isinstance(cats, list) or not all(isinstance(c, str) for c in cats):
        raise HttpError(400, "categories must be a list of category names")
    bad = [c for c in cats if c not in CATEGORY_ORDER]
    if bad:
        raise HttpError(400, f"not a category: {', '.join(bad)}")
    home = field["category"]
    # `categories` is the whole set of headings the manager wants, home
    # included or not. Admin's site-wide decisions are not theirs to undo, so
    # those are folded in regardless of what was sent.
    site_extra = [r["category"] for r in rows(ctx.conn.execute(
        "SELECT category FROM spec_field_categories WHERE field_key=? AND shown=1", (field_key,)))]
    site_hides_home = ctx.conn.execute(
        "SELECT 1 FROM spec_field_categories WHERE field_key=? AND shown=0", (field_key,)).fetchone()
    extras = [c for c in CATEGORY_ORDER if (c in cats or c in site_extra) and c != home]
    home_shown = home in cats and not site_hides_home
    # An empty set is allowed: the spec then shows in the header only -- if it
    # is pinned there, or is a General field -- and under no heading at all.
    # Only the manager's own ticks are stored. A site-wide heading is admin's
    # row, not this bike's; keeping a copy here would outlive admin clearing it.
    own = [c for c in extras if c not in site_extra]

    was = rows(ctx.conn.execute(
        "SELECT category, shown FROM bike_spec_categories WHERE bike_id=? AND field_key=?",
        (bike_id, field_key)))
    ctx.conn.execute("DELETE FROM bike_spec_categories WHERE bike_id=? AND field_key=?",
                     (bike_id, field_key))
    for c in own:
        ctx.conn.execute(
            "INSERT INTO bike_spec_categories (bike_id, field_key, category, shown, placed_by)"
            " VALUES (?,?,?,1,?)", (bike_id, field_key, c, ctx.user["id"]))
    if not home_shown and not site_hides_home:
        ctx.conn.execute(
            "INSERT INTO bike_spec_categories (bike_id, field_key, category, shown, placed_by)"
            " VALUES (?,?,?,0,?)", (bike_id, field_key, home, ctx.user["id"]))
    shown = ([home] if home_shown else []) + extras
    name = one(ctx.conn.execute("SELECT display_name FROM bike_display WHERE bike_id=?",
                                (bike_id,)))["display_name"]
    log_action(ctx, "spec.categories",
               f'"{field["label"]}" on {name} shows under {", ".join(shown) or "no heading (header only)"}',
               target=field_key, detail={"bike_id": bike_id, "was": was, "now": shown})
    ctx.conn.commit()
    return {"ok": True, "field_key": field_key, "home": home, "home_shown": home_shown,
            "shown": shown, "also_in": shown[1:]}


@route("PATCH", r"/api/admin/fields/([a-z0-9_]+)/categories", role="admin")
def set_field_categories(ctx):
    """Show a field under extra headings on every bike.

    Admin-only for the same reason the home category is: it changes every
    spec sheet at once. The home category is not touched; the extra headings
    carry a pointer to the row, not a second copy of it.
    """
    field_key = ctx.params[0]
    field = one(ctx.conn.execute(
        "SELECT label, category FROM spec_fields WHERE field_key=?", (field_key,)))
    if not field:
        raise HttpError(404, "no such field")
    cats = ctx.body.get("categories")
    if not isinstance(cats, list) or not all(isinstance(c, str) for c in cats):
        raise HttpError(400, "categories must be a list of category names")
    bad = [c for c in cats if c not in CATEGORY_ORDER]
    if bad:
        raise HttpError(400, f"not a category: {', '.join(bad)}")
    home = field["category"]
    extras = [c for c in CATEGORY_ORDER if c in cats and c != home]
    home_shown = home in cats
    was = rows(ctx.conn.execute(
        "SELECT category, shown FROM spec_field_categories WHERE field_key=?", (field_key,)))
    ctx.conn.execute("DELETE FROM spec_field_categories WHERE field_key=?", (field_key,))
    for c in extras:
        ctx.conn.execute(
            "INSERT INTO spec_field_categories (field_key, category, shown, placed_by)"
            " VALUES (?,?,1,?)", (field_key, c, ctx.user["id"]))
    if not home_shown:
        ctx.conn.execute(
            "INSERT INTO spec_field_categories (field_key, category, shown, placed_by)"
            " VALUES (?,?,0,?)", (field_key, home, ctx.user["id"]))
    shown = ([home] if home_shown else []) + extras
    bikes = ctx.conn.execute("SELECT COUNT(DISTINCT bike_id) FROM specs WHERE field_key=?",
                             (field_key,)).fetchone()[0]
    log_action(ctx, "field.categories",
               f'"{field["label"]}" shows under {", ".join(shown) or "no heading (header only)"} on every bike',
               target=field_key, detail={"was": was, "now": shown, "bikes": bikes})
    ctx.conn.commit()
    return {"ok": True, "field_key": field_key, "home": home, "home_shown": home_shown,
            "shown": shown, "also_in": extras, "bikes": bikes}


@route("GET", r"/api/admin/notices", role="admin")
def admin_notices(ctx):
    """What managers changed about their bikes, unseen first."""
    return {"items": rows(ctx.conn.execute(
        "SELECT n.id, n.kind, n.summary, n.detail, n.created_at, n.seen_at,"
        " n.bike_id, d.display_name AS bike_name, d.year_range,"
        " u.username AS actor"
        " FROM manager_notices n"
        " LEFT JOIN users u ON u.id = n.actor"
        " LEFT JOIN bike_display d ON d.bike_id = n.bike_id"
        " WHERE n.seen_at IS NULL ORDER BY n.created_at DESC LIMIT 200")),
        "unseen": ctx.conn.execute(
            "SELECT COUNT(*) FROM manager_notices WHERE seen_at IS NULL").fetchone()[0]}


@route("POST", r"/api/admin/notices/seen", role="admin")
def admin_notices_seen(ctx):
    """Mark one notice seen (`id`), or all of them (no id)."""
    nid = ctx.body.get("id")
    if nid is None:
        cur = ctx.conn.execute(
            "UPDATE manager_notices SET seen_by=?, seen_at=datetime('now')"
            " WHERE seen_at IS NULL", (ctx.user["id"],))
    else:
        cur = ctx.conn.execute(
            "UPDATE manager_notices SET seen_by=?, seen_at=datetime('now')"
            " WHERE id=? AND seen_at IS NULL", (ctx.user["id"], int(nid)))
    ctx.conn.commit()
    return {"ok": True, "seen": cur.rowcount}


@route("POST", r"/api/admin/bikes/(\d+)/verify-years", role="admin")
def verify_years(ctx):
    bike_id = int(ctx.params[0])
    name = ctx.conn.execute("SELECT display_name, year_range FROM bike_display"
                            " WHERE bike_id=?", (bike_id,)).fetchone()
    ctx.conn.execute("UPDATE bikes SET years_verified=1 WHERE id=?", (bike_id,))
    log_action(ctx, "bike.verify_years",
               f"Confirmed the year span for {name[0]} ({name[1]})" if name
               else f"Confirmed the year span for bike {bike_id}",
               target=str(bike_id))
    ctx.conn.commit()
    return {"ok": True}


# ---------------------------------------------------------------------------
# Assigning managers to bikes.
#
# Only an admin does this. A manager does not choose which bikes they look
# after, which is what makes "the person closest to the bike" mean something —
# it is a responsibility handed out, not claimed.
# ---------------------------------------------------------------------------
@route("GET", r"/api/admin/assignments", role="admin")
def admin_assignments(ctx):
    return {
        "assignments": rows(ctx.conn.execute(
            "SELECT m.id, m.bike_id, m.specialty, m.created_at,"
            " u.id AS user_id, u.username, u.display_name, u.role,"
            " d.display_name AS bike_name, d.year_range,"
            " p.specs_filled, p.specs_needed,"
            " (SELECT COUNT(*) FROM value_flags vf JOIN specs s ON s.id=vf.spec_id"
            "   WHERE s.bike_id=m.bike_id AND vf.status='open') AS open_flags"
            " FROM bike_managers m"
            " JOIN users u ON u.id = m.user_id"
            " JOIN bike_display d ON d.bike_id = m.bike_id"
            " JOIN bike_spec_progress p ON p.bike_id = m.bike_id"
            " ORDER BY d.display_name")),
        # Candidates for the dropdown: anyone who is not an admin. Admins reach
        # every bike already, so assigning one is a no-op that would just make
        # the list confusing.
        "candidates": rows(ctx.conn.execute(
            "SELECT id, username, display_name, role,"
            " (SELECT COUNT(*) FROM bike_managers m WHERE m.user_id=u.id) AS bikes"
            " FROM users u WHERE role <> 'admin' AND suspended = 0"
            # People who already manage something first — they are the likelier
            # pick — then everyone else, each alphabetical.
            " ORDER BY (role = 'manager') DESC, username")),
        # Bikes with nobody looking after them — the ones actually worth
        # assigning. Capped, since most of the 258-bike catalog is unmanaged.
        "unassigned": rows(ctx.conn.execute(
            "SELECT d.bike_id, d.display_name, d.year_range,"
            " p.fields_triggered, p.specs_filled"
            " FROM bike_display d"
            " JOIN bike_spec_progress p ON p.bike_id = d.bike_id"
            " WHERE NOT EXISTS (SELECT 1 FROM bike_managers m WHERE m.bike_id = d.bike_id)"
            " ORDER BY p.specs_filled DESC, d.display_name LIMIT 300")),
    }


@route("POST", r"/api/admin/bikes/(\d+)/manager", role="admin")
def assign_manager(ctx):
    bike_id = int(ctx.params[0])
    user_id = int(ctx.field("user_id"))
    if not ctx.conn.execute("SELECT 1 FROM bikes WHERE id=?", (bike_id,)).fetchone():
        raise HttpError(404, "bike not found")
    u = one(ctx.conn.execute("SELECT * FROM users WHERE id=?", (user_id,)))
    if not u:
        raise HttpError(404, "user not found")
    if u["suspended"]:
        raise HttpError(400, "that account is suspended")
    if u["role"] == "admin":
        raise HttpError(400, "admins already reach every bike — "
                             "assigning one would not change anything")
    try:
        ctx.conn.execute(
            "INSERT INTO bike_managers (user_id, bike_id, specialty) VALUES (?,?,?)",
            (user_id, bike_id, ctx.body.get("specialty")))
    except sqlite3.IntegrityError:
        raise HttpError(409, "that person already manages this bike")

    # Being handed a bike is what makes someone a bike manager. Without this the
    # assignment would exist but every manager route would still 403 them.
    promoted = u["role"] == "user"
    if promoted:
        ctx.conn.execute("UPDATE users SET role='manager' WHERE id=?", (user_id,))
    bike = ctx.conn.execute("SELECT display_name FROM bike_display WHERE bike_id=?",
                            (bike_id,)).fetchone()[0]
    log_action(ctx, "manager.assign",
               f'Assigned {u["username"]} to {bike}'
               + (" (promoted to manager)" if promoted else ""),
               target=str(bike_id),
               detail={"user": u["username"], "bike_id": bike_id,
                       "bike": bike, "promoted": promoted})
    ctx.conn.commit()
    return {"ok": True, "promoted": promoted}


@route("DELETE", r"/api/admin/bikes/(\d+)/manager/(\d+)", role="admin")
def unassign_manager(ctx):
    bike_id, user_id = int(ctx.params[0]), int(ctx.params[1])
    cur = ctx.conn.execute(
        "DELETE FROM bike_managers WHERE bike_id=? AND user_id=?", (bike_id, user_id))
    if not cur.rowcount:
        raise HttpError(404, "that person does not manage this bike")

    # A 'manager' with no bikes has manager access to nothing, so the label
    # would just be wrong. Admins are left alone.
    remaining = ctx.conn.execute(
        "SELECT COUNT(*) FROM bike_managers WHERE user_id=?", (user_id,)).fetchone()[0]
    demoted = False
    if not remaining:
        cur2 = ctx.conn.execute(
            "UPDATE users SET role='user' WHERE id=? AND role='manager'", (user_id,))
        demoted = bool(cur2.rowcount)
    who = ctx.conn.execute("SELECT username FROM users WHERE id=?", (user_id,)).fetchone()
    bike = ctx.conn.execute("SELECT display_name FROM bike_display WHERE bike_id=?",
                            (bike_id,)).fetchone()
    log_action(ctx, "manager.unassign",
               f'Removed {who[0] if who else user_id} from '
               f'{bike[0] if bike else bike_id}'
               + (" (set back to user)" if demoted else ""),
               target=str(bike_id),
               detail={"user_id": user_id, "bike_id": bike_id, "demoted": demoted})
    ctx.conn.commit()
    return {"ok": True, "demoted": demoted}


@route("GET", r"/api/users", role="admin")
def list_users(ctx):
    """Every account, with the email. Admin only -- this is the one place the
    address is returned; user_profile_stats, which the public profile reads,
    deliberately does not carry it."""
    return {"users": rows(ctx.conn.execute(
        "SELECT p.*, u.email, u.suspended, u.created_at,"
        " (SELECT COUNT(*) FROM bike_managers m WHERE m.user_id = u.id) AS bikes_managed"
        " FROM user_profile_stats p JOIN users u ON u.id = p.user_id"
        " ORDER BY u.created_at DESC, u.username"))}


# ===========================================================================
# HTTP plumbing
# ===========================================================================
class Handler(BaseHTTPRequestHandler):
    server_version = "GearHeadSpecs"

    def log_message(self, fmt, *args):
        pass

    # -- helpers ----------------------------------------------------------
    def _send_json(self, status, payload, cookie=None, clear_cookie=False):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        # No CORS header: the pages are served from this same origin, and a
        # permissive one alongside cookie auth is a liability, not a feature.
        if cookie:
            self.send_header("Set-Cookie",
                             f"{COOKIE_NAME}={cookie}; HttpOnly; SameSite=Lax;"
                             f" Path=/; Max-Age={SESSION_DAYS * 86400}")
        if clear_cookie:
            self.send_header("Set-Cookie",
                             f"{COOKIE_NAME}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0")
        self.end_headers()
        self.wfile.write(body)

    def _cookie_token(self):
        raw = self.headers.get("Cookie")
        if not raw:
            return None
        try:
            return SimpleCookie(raw).get(COOKIE_NAME).value
        except Exception:
            return None

    def _read_body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return {}
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        # An image comes as itself. It is handed to the route as bytes under
        # "_raw"; the route decides what it really is from the bytes.
        if ctype.startswith("image/"):
            if length > PHOTO_MAX_BYTES:
                # Drain what the client is still sending, within reason, so the
                # 413 reaches it instead of a reset connection. Past that it
                # is not a photo, and the connection can drop.
                left = min(length, PHOTO_MAX_BYTES * 3)
                while left > 0:
                    left -= len(self.rfile.read(min(left, 65536)) or b"x")
                raise HttpError(413, f"the photo is over {PHOTO_MAX_BYTES // (1024 * 1024)} MB")
            return {"_raw": self.rfile.read(length), "_ctype": ctype}
        try:
            return json.loads(self.rfile.read(length))
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise HttpError(400, "body must be valid JSON")

    # -- dispatch ---------------------------------------------------------
    def _handle(self, method):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)

        if not path.startswith("/api/"):
            return self._serve_static(path)

        conn = db()
        try:
            # DELETE included: the destructive removals carry their confirmation
            # in the body ({"force": true}). Without reading it here the flag was
            # dropped silently and every confirmed delete came back refused.
            body = (self._read_body()
                    if method in ("POST", "PATCH", "PUT", "DELETE") else {})
            user = user_for_token(conn, self._cookie_token())

            matched_path = False
            for m, pattern, fn, role in ROUTES:
                hit = pattern.match(path)
                if not hit:
                    continue
                matched_path = True
                if m != method:
                    continue

                if role != "anon":
                    if not user:
                        raise HttpError(401, "sign in to do that")
                    if user["suspended"]:
                        raise HttpError(403, "this account is suspended")
                    if ROLE_RANK[user["role"]] < ROLE_RANK.get(role, 0):
                        raise HttpError(403, f"requires {role} access")

                result = fn(Ctx(conn, user, hit.groups(), parse_qs(parsed.query), body))
                cookie = result.pop("_set_cookie", None) if isinstance(result, dict) else None
                clear = result.pop("_clear_cookie", False) if isinstance(result, dict) else False
                return self._send_json(200, result, cookie=cookie, clear_cookie=clear)

            if matched_path:
                raise HttpError(405, f"{method} not allowed on this path")
            raise HttpError(404, "no such endpoint")

        except HttpError as e:
            self._send_json(e.status, {"error": e.message})
        except sqlite3.IntegrityError as e:
            self._send_json(409, {"error": f"database constraint: {e}"})
        except Exception as e:  # noqa: BLE001 - last resort, keeps the server up
            import traceback
            traceback.print_exc()
            self._send_json(500, {"error": f"{type(e).__name__}: {e}"})
        finally:
            conn.close()

    def _serve_static(self, path):
        rel = path.lstrip("/") or "index.html"
        # Bike photos live with the data, not the code, and are served from
        # there under the same traversal guard.
        base = STATIC_DIR
        if rel.startswith("photos/"):
            base, rel = PHOTO_DIR, rel[len("photos/"):]
        full = os.path.normpath(os.path.join(base, rel))
        # normpath first, then confirm we are still inside the served directory:
        # without this a path of ../../ walks straight out of it.
        if not full.startswith(base + os.sep) and full != base:
            self._send_json(403, {"error": "forbidden"})
            return
        if os.path.isdir(full):
            full = os.path.join(full, "index.html")
        if not os.path.isfile(full):
            self.send_response(404)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"404 - not found")
            return
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        with open(full, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):    self._handle("GET")
    def do_POST(self):   self._handle("POST")
    def do_PATCH(self):  self._handle("PATCH")
    def do_DELETE(self): self._handle("DELETE")


def main():
    if not os.path.exists(DB_PATH):
        raise SystemExit("data.db not found — run:  py seed.py")
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"GearHeadSpecs running on http://127.0.0.1:{PORT}/")
    print("Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")


if __name__ == "__main__":
    main()
