"""
Wire colours as a value type, not as free text.

A wire colour is a base colour and up to two stripes. Typed as text, one wire
comes back as "yellow w/ red", "Yel/Red", "Y/R" and "yellow red stripe" from
four different riders, and none of them sort, match or compare.

Stored canonically as colour keys -- "yellow/red" -- and rendered in whatever
abbreviation the bike's own manufacturer prints on its wiring diagram. Honda
calls blue Bu, Kawasaki calls it BL, Harley calls it BE. The rider is reading
their own manual, so the page should speak their manual's language while the
database keeps one form.

The abbreviation tables came from the mockup and each row still wants checking
against a real wiring diagram for that make before it is relied on.
"""

# Ordered as the picker shows them. The hex is for the swatch, `light` says
# whether the jacket needs a darker outline to be visible on a pale page.
COLORS = {
    "black":      {"name": "Black",       "hex": "#1F1F22", "light": False},
    "white":      {"name": "White",       "hex": "#F4F4F1", "light": True},
    "red":        {"name": "Red",         "hex": "#D42B23", "light": False},
    "blue":       {"name": "Blue",        "hex": "#1F5FBF", "light": False},
    "lightblue":  {"name": "Light blue",  "hex": "#6FB5E8", "light": True},
    "green":      {"name": "Green",       "hex": "#1E8A3C", "light": False},
    "lightgreen": {"name": "Light green", "hex": "#8ED66F", "light": True},
    "yellow":     {"name": "Yellow",      "hex": "#F3D22B", "light": True},
    "brown":      {"name": "Brown",       "hex": "#6E3F1E", "light": False},
    "orange":     {"name": "Orange",      "hex": "#F07A1C", "light": False},
    "pink":       {"name": "Pink",        "hex": "#F09AB8", "light": True},
    "gray":       {"name": "Gray",        "hex": "#8E9096", "light": False},
    "purple":     {"name": "Purple",      "hex": "#6A3FA6", "light": False},
    "tan":        {"name": "Tan",         "hex": "#C9A66B", "light": True},
}

ABBR = {
    "Honda": {"black": "B", "white": "W", "red": "R", "blue": "Bu",
              "lightblue": "Lb", "green": "G", "lightgreen": "Lg",
              "yellow": "Y", "brown": "Br", "orange": "O", "pink": "P",
              "gray": "Gr", "purple": "V", "tan": "Tn"},
    "Yamaha": {"black": "B", "white": "W", "red": "R", "blue": "L",
               "lightblue": "Sb", "green": "G", "lightgreen": "Lg",
               "yellow": "Y", "brown": "Br", "orange": "O", "pink": "P",
               "gray": "Gy", "purple": "Pu", "tan": "Tn"},
    "Kawasaki": {"black": "BK", "white": "W", "red": "R", "blue": "BL",
                 "lightblue": "LB", "green": "G", "lightgreen": "LG",
                 "yellow": "Y", "brown": "BR", "orange": "O", "pink": "P",
                 "gray": "GY", "purple": "PU", "tan": "TN"},
    "Suzuki": {"black": "B", "white": "W", "red": "R", "blue": "Bl",
               "lightblue": "Lbl", "green": "G", "lightgreen": "Lg",
               "yellow": "Y", "brown": "Br", "orange": "O", "pink": "P",
               "gray": "Gr", "purple": "V", "tan": "Tn"},
    "Harley-Davidson": {"black": "BK", "white": "W", "red": "R", "blue": "BE",
                        "lightblue": "LTBE", "green": "GN",
                        "lightgreen": "LTGN", "yellow": "Y", "brown": "BN",
                        "orange": "O", "pink": "PK", "gray": "GY",
                        "purple": "V", "tan": "TN"},
    "default": {"black": "BK", "white": "W", "red": "R", "blue": "BL",
                "lightblue": "LB", "green": "G", "lightgreen": "LG",
                "yellow": "Y", "brown": "BR", "orange": "O", "pink": "PK",
                "gray": "GY", "purple": "PU", "tan": "TN"},
}

MAX_STRIPES = 2          # base + 2 stripes; second is rare but real on BMW/Ducati
MAX_WIRES = 8            # a stator is 3, an R/R connector 5, a switch block up to 8
MAX_ROLE = 40


class WireColorError(ValueError):
    """A value that is not a wire colour this vocabulary can express."""


def _slug(part):
    """Fold a written colour onto its key, so an existing free-text value can
    be adopted rather than thrown away: 'Light Blue' and 'lightblue' are one."""
    return "".join(ch for ch in part.lower() if ch.isalnum())


_BY_SLUG = {_slug(k): k for k in COLORS}
_BY_SLUG.update({_slug(v["name"]): k for k, v in COLORS.items()})


def parse(value):
    """Canonical key list for a wire colour, or raise.

    Accepts what people already typed -- "Yellow/Red", "yellow / red" -- so the
    values on the site before this existed do not need re-entering.
    """
    if value is None or not str(value).strip():
        raise WireColorError("a wire colour needs at least a base colour")
    parts = [p.strip() for p in str(value).split("/") if p.strip()]
    if not parts:
        raise WireColorError("a wire colour needs at least a base colour")
    if len(parts) > 1 + MAX_STRIPES:
        raise WireColorError(
            f"at most a base colour and {MAX_STRIPES} stripes")
    keys = []
    for part in parts:
        key = _BY_SLUG.get(_slug(part))
        if key is None:
            raise WireColorError(
                f"{part!r} is not a colour on the list "
                f"({', '.join(COLORS[k]['name'] for k in COLORS)})")
        keys.append(key)
    if len(set(keys)) != len(keys):
        raise WireColorError("a stripe cannot repeat the colour under it")
    return keys


def normalise(value):
    """The form that goes in the database: 'yellow/red'."""
    return "/".join(parse(value))


def abbreviate(value, make=None):
    """The form the rider sees, in their own manufacturer's shorthand."""
    table = ABBR.get(make or "", ABBR["default"])
    return "/".join(table[k] for k in parse(value))


def describe(value):
    """Plain words, for a screen reader and for anyone who does not read the
    abbreviations: 'Yellow / red stripe'."""
    keys = parse(value)
    out = COLORS[keys[0]]["name"]
    for k in keys[1:]:
        out += " / " + COLORS[k]["name"].lower() + " stripe"
    return out


# --------------------------------------------------------------------------
# A spec can be more than one wire.
#
# A kickstand switch has two. Recorded as one wire each they become two specs,
# or -- as actually happened here -- two "alternates" competing for votes when
# both are correct and neither replaces the other. A wire colour value is
# therefore a LIST of wires, written comma-separated:
#
#     green/white, green/black
#
# with an optional role per wire, which is what tells two otherwise similar
# wires apart and becomes necessary once there are more than two:
#
#     to switch: green/white, to harness: green/black
#
# One wire is a list of one, so every value written before this still parses
# and still means the same thing.
# --------------------------------------------------------------------------

def parse_set(value):
    """[(role_or_None, [colour keys]), ...] for a wire colour value."""
    if value is None or not str(value).strip():
        raise WireColorError("a wire colour needs at least a base colour")
    chunks = [c.strip() for c in str(value).split(",") if c.strip()]
    if not chunks:
        raise WireColorError("a wire colour needs at least a base colour")
    if len(chunks) > MAX_WIRES:
        raise WireColorError(f"at most {MAX_WIRES} wires on one spec")

    out = []
    for chunk in chunks:
        role = None
        if ":" in chunk:
            role, chunk = chunk.split(":", 1)
            role, chunk = role.strip(), chunk.strip()
            if not role:
                role = None
            elif len(role) > MAX_ROLE:
                raise WireColorError(
                    f"a wire's role is limited to {MAX_ROLE} characters")
        out.append((role, parse(chunk)))

    roles = [r for r, _ in out if r]
    if len(set(roles)) != len(roles):
        raise WireColorError("two wires cannot share the same role")
    return out


def normalise_set(value):
    """The form that goes in the database."""
    return ", ".join(
        (f"{role}: " if role else "") + "/".join(keys)
        for role, keys in parse_set(value))


def describe_set(value, make=None):
    """One readable line per wire, for a page or a screen reader."""
    table = ABBR.get(make or "", ABBR["default"])
    out = []
    for role, keys in parse_set(value):
        abbr = "/".join(table[k] for k in keys)
        name = COLORS[keys[0]]["name"] + "".join(
            " / " + COLORS[k]["name"].lower() + " stripe" for k in keys[1:])
        out.append({"role": role, "value": "/".join(keys),
                    "abbr": abbr, "name": name})
    return out


def vocabulary(make=None):
    """Everything a client needs to render and offer wire colours."""
    table = ABBR.get(make or "", ABBR["default"])
    return {
        "colors": [{"key": k, "name": v["name"], "hex": v["hex"],
                    "light": v["light"], "abbr": table[k]}
                   for k, v in COLORS.items()],
        "make": make,
        "max_stripes": MAX_STRIPES,
        "max_wires": MAX_WIRES,
        "max_role": MAX_ROLE,
    }
